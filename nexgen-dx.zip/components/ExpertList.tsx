
import React, { useState, useMemo, useEffect } from 'react';
import { 
  Star, 
  MessageSquare, 
  Clock, 
  Search, 
  BadgeCheck, 
  Filter, 
  Sparkles, 
  BrainCircuit, 
  ChevronRight, 
  MapPin, 
  Briefcase, 
  Globe2, 
  X,
  CalendarCheck,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { ExpertProfile, Language, AssessmentResult } from '../types';
import { generateConsultationBrief } from '../services/geminiService';

interface ExpertListProps {
  language: Language;
  assessmentResult: AssessmentResult | null;
  initialSearchTerm?: string;
}

const MOCK_EXPERTS: ExpertProfile[] = [
  {
    id: '1',
    name: 'Dr. Sarah Chen',
    role: 'Chief Data Strategist',
    company: 'Ex-Google DeepMind',
    specialty: ['Big Data', 'AI Governance', 'Retail', 'Predictive Analytics'],
    rating: 4.9,
    reviewCount: 124,
    hourlyRate: 350,
    currency: '$',
    imageUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=200&auto=format&fit=crop',
    available: true,
    verified: true,
    languages: ['English', 'Mandarin'],
    experienceYears: 15,
    bio: "Ph.D. in Computer Science with 15 years of experience leading data strategies for Fortune 500 retailers. Specializes in turning messy data warehouses into actionable predictive engines."
  },
  {
    id: '2',
    name: 'Marcus Reynolds',
    role: 'Cloud Architecture Lead',
    company: 'CloudNative Solutions',
    specialty: ['AWS Migration', 'Microservices', 'FinTech', 'Security'],
    rating: 4.8,
    reviewCount: 89,
    hourlyRate: 275,
    currency: '$',
    imageUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=200&auto=format&fit=crop',
    available: true,
    verified: true,
    languages: ['English', 'German'],
    experienceYears: 12,
    bio: "Certified AWS Solutions Architect Professional. I help legacy financial institutions migrate to the cloud without breaking compliance or security protocols."
  },
  {
    id: '3',
    name: 'Elena Rodriguez',
    role: 'Agile Transformation Coach',
    company: 'Independent',
    specialty: ['Scrum', 'Organizational Culture', 'SaaS', 'Process Optimization'],
    rating: 5.0,
    reviewCount: 215,
    hourlyRate: 300,
    currency: '$',
    imageUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=200&auto=format&fit=crop',
    available: false,
    verified: true,
    languages: ['English', 'Spanish'],
    experienceYears: 18,
    bio: "Transforming rigid corporate structures into agile powerhouses. I focus on the 'People' and 'Process' pillars of digital transformation."
  },
  {
    id: '4',
    name: 'James Foster',
    role: 'Security & Compliance Expert',
    company: 'CyberSecure Corp',
    specialty: ['GDPR', 'Cybersecurity', 'Healthcare', 'Risk Management'],
    rating: 4.7,
    reviewCount: 56,
    hourlyRate: 325,
    currency: '$',
    imageUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=200&auto=format&fit=crop',
    available: true,
    verified: true,
    languages: ['English'],
    experienceYears: 20,
    bio: "Former CISO for a major hospital network. I ensure your digital transformation doesn't open the door to hackers or regulatory fines."
  },
  {
    id: '5',
    name: 'Aisha Patel',
    role: 'Blockchain Consultant',
    company: 'Web3 Ventures',
    specialty: ['Web3', 'Smart Contracts', 'Supply Chain', 'Traceability'],
    rating: 4.9,
    reviewCount: 42,
    hourlyRate: 400,
    currency: '$',
    imageUrl: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?q=80&w=200&auto=format&fit=crop',
    available: true,
    verified: true,
    languages: ['English', 'Hindi', 'French'],
    experienceYears: 8,
    bio: "Bridging the gap between enterprise supply chains and decentralized ledgers. Let's build transparent, trustless systems."
  },
  {
    id: '6',
    name: 'Robert Kim',
    role: 'Digital Marketing Lead',
    company: 'GrowthHackers',
    specialty: ['Growth Hacking', 'SEO', 'E-commerce', 'Customer Analytics'],
    rating: 4.6,
    reviewCount: 110,
    hourlyRate: 220,
    currency: '$',
    imageUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=200&auto=format&fit=crop',
    available: true,
    verified: false,
    languages: ['English', 'Korean'],
    experienceYears: 10,
    bio: "Data-driven marketing strategist. I help e-commerce brands scale from 7 to 8 figures using automation and personalized customer journeys."
  }
];

export const ExpertList: React.FC<ExpertListProps> = ({ language, assessmentResult, initialSearchTerm }) => {
  const [searchTerm, setSearchTerm] = useState(initialSearchTerm || '');
  const [aiMatchMode, setAiMatchMode] = useState(false);
  const [selectedExpert, setSelectedExpert] = useState<ExpertProfile | null>(null);
  const [isBooking, setIsBooking] = useState(false);
  const [bookingStep, setBookingStep] = useState<1 | 2 | 3>(1);
  const [generatedBrief, setGeneratedBrief] = useState('');
  const [isGeneratingBrief, setIsGeneratingBrief] = useState(false);

  useEffect(() => {
    if (initialSearchTerm) {
      setSearchTerm(initialSearchTerm);
    }
  }, [initialSearchTerm]);

  const t = {
    en: {
      title: "Expert Marketplace",
      subtitle: "Connect with top-tier consultants to execute your roadmap.",
      connect: "Connect",
      viewProfile: "View Profile",
      book: "Book Consultation",
      hr: "/hr",
      searchPlaceholder: "Search by name, role, or skill...",
      noResults: "No experts found matching your criteria.",
      aiMatch: "AI Match",
      aiMatchDesc: "Sort by relevance to your assessment",
      enableAi: "Enable AI Match",
      disableAi: "Show All",
      verified: "Verified Pro",
      exp: "Exp",
      years: "yrs",
      reviews: "reviews",
      about: "About",
      languages: "Languages",
      skills: "Core Competencies",
      bookingTitle: "Book Consultation",
      briefing: "AI-Generated Briefing",
      briefingDesc: "NexGen AI has analyzed your assessment and drafted this introduction for the expert.",
      confirm: "Confirm Booking",
      success: "Booking Request Sent!",
      successDesc: "The expert will review your brief and propose times within 24 hours.",
      noAssessment: "Complete Assessment to use AI Match"
    },
    vi: {
      title: "Sàn Chuyên Gia",
      subtitle: "Kết nối với các chuyên gia tư vấn hàng đầu để thực hiện lộ trình của bạn.",
      connect: "Kết nối",
      viewProfile: "Xem Hồ Sơ",
      book: "Đặt Lịch Tư Vấn",
      hr: "/giờ",
      searchPlaceholder: "Tìm theo tên, vai trò hoặc kỹ năng...",
      noResults: "Không tìm thấy chuyên gia nào phù hợp.",
      aiMatch: "AI Ghép Cặp",
      aiMatchDesc: "Sắp xếp theo mức độ phù hợp với đánh giá",
      enableAi: "Bật AI Match",
      disableAi: "Hiện tất cả",
      verified: "Đã xác thực",
      exp: "Kinh nghiệm",
      years: "năm",
      reviews: "đánh giá",
      about: "Giới thiệu",
      languages: "Ngôn ngữ",
      skills: "Năng lực cốt lõi",
      bookingTitle: "Đặt Lịch Tư Vấn",
      briefing: "Tóm tắt từ AI",
      briefingDesc: "NexGen AI đã phân tích đánh giá của bạn và soạn thảo lời giới thiệu này.",
      confirm: "Xác nhận đặt lịch",
      success: "Đã gửi yêu cầu!",
      successDesc: "Chuyên gia sẽ xem xét và đề xuất thời gian trong vòng 24 giờ.",
      noAssessment: "Hoàn thành đánh giá để dùng AI Match"
    }
  }[language];

  // AI Matching Logic (Client-side simulation based on keywords)
  const filteredAndSortedExperts = useMemo(() => {
    let result = MOCK_EXPERTS.filter(expert => {
      const term = searchTerm.toLowerCase();
      return (
        expert.name.toLowerCase().includes(term) ||
        expert.role.toLowerCase().includes(term) ||
        expert.specialty.some(s => s.toLowerCase().includes(term))
      );
    });

    if (aiMatchMode && assessmentResult) {
      // Simple relevance scoring: matching roadmap titles or summary keywords to expert specialty
      const keywords = assessmentResult.roadmap.map(r => r.title.toLowerCase())
        .concat(assessmentResult.industry ? [assessmentResult.industry.toLowerCase()] : [])
        .join(' ');
      
      result = result.map(expert => {
        let score = 0;
        expert.specialty.forEach(s => {
          if (keywords.includes(s.toLowerCase())) score += 2;
        });
        if (expert.role.toLowerCase().includes(assessmentResult.industry?.toLowerCase() || '')) score += 3;
        return { ...expert, matchScore: score };
      }).sort((a: any, b: any) => b.matchScore - a.matchScore);
    }

    return result;
  }, [searchTerm, aiMatchMode, assessmentResult]);

  const handleBookClick = async () => {
    if (!selectedExpert) return;
    setIsBooking(true);
    setBookingStep(1);
    
    if (assessmentResult) {
      setIsGeneratingBrief(true);
      try {
        const brief = await generateConsultationBrief(
          selectedExpert.name, 
          selectedExpert.role, 
          assessmentResult.summary, 
          language
        );
        setGeneratedBrief(brief);
      } catch (e) {
        console.error(e);
      } finally {
        setIsGeneratingBrief(false);
      }
    }
  };

  return (
    <div className="p-6 md:p-8 h-full overflow-y-auto bg-brand-black relative">
      {/* HEADER SECTION */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-8 gap-6">
        <div>
          <h2 className="text-3xl font-display font-bold text-white mb-2">{t.title}</h2>
          <p className="text-brand-gray">{t.subtitle}</p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-4 w-full lg:w-auto">
          {/* AI Match Toggle */}
          <div className="relative group">
             <button
                onClick={() => assessmentResult && setAiMatchMode(!aiMatchMode)}
                disabled={!assessmentResult}
                className={`w-full md:w-auto flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl border transition-all ${
                  aiMatchMode 
                    ? 'bg-gradient-to-r from-brand-wine to-brand-red border-brand-bright text-white shadow-[0_0_20px_rgba(229,56,59,0.3)]' 
                    : 'bg-brand-dark border-white/10 text-brand-gray hover:border-brand-bright/50'
                } ${!assessmentResult ? 'opacity-50 cursor-not-allowed' : ''}`}
             >
                <BrainCircuit size={18} className={aiMatchMode ? "animate-pulse" : ""} />
                <span className="font-bold text-sm">{aiMatchMode ? t.disableAi : t.enableAi}</span>
             </button>
             {!assessmentResult && (
               <div className="absolute top-full mt-2 right-0 w-max bg-brand-dark border border-white/10 p-2 rounded text-xs text-brand-gray opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20">
                 {t.noAssessment}
               </div>
             )}
          </div>

          {/* Search Bar */}
          <div className="relative w-full md:w-72 group">
            <input 
              type="text" 
              placeholder={t.searchPlaceholder}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-brand-dark border border-white/10 rounded-xl py-2.5 pl-10 pr-4 text-white placeholder-brand-gray/50 focus:outline-none focus:border-brand-bright/50 focus:ring-1 focus:ring-brand-bright/50 transition-all"
            />
            <Search className="absolute left-3 top-3 text-brand-gray group-focus-within:text-brand-bright transition-colors" size={18} />
          </div>
        </div>
      </div>

      {/* EXPERT GRID */}
      {filteredAndSortedExperts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-brand-gray border border-dashed border-white/10 rounded-2xl bg-brand-dark/20">
           <Filter size={48} className="mb-4 opacity-50" />
           <p>{t.noResults}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 pb-10">
          {filteredAndSortedExperts.map((expert: any) => (
            <div 
              key={expert.id} 
              className={`relative bg-brand-dark border rounded-2xl p-5 hover:border-brand-bright/50 transition-all duration-300 group shadow-lg flex flex-col overflow-hidden ${
                aiMatchMode && expert.matchScore > 3 ? 'border-brand-bright/40 bg-gradient-to-br from-brand-dark to-brand-wine/10' : 'border-white/5'
              }`}
            >
              {aiMatchMode && expert.matchScore > 3 && (
                <div className="absolute top-3 right-3 z-10">
                   <span className="flex items-center gap-1 bg-brand-bright text-white text-[10px] font-bold px-2 py-1 rounded-full shadow-lg shadow-brand-red/40 animate-pulse">
                     <Sparkles size={10} /> AI Recommended
                   </span>
                </div>
              )}
              
              {/* Card Header */}
              <div className="flex items-start gap-4 mb-4">
                <div className="relative shrink-0">
                  <img src={expert.imageUrl} alt={expert.name} className="w-16 h-16 rounded-2xl object-cover border border-white/10 group-hover:border-brand-bright transition-colors shadow-lg" />
                  {expert.available && (
                    <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-brand-dark rounded-full"></span>
                  )}
                </div>
                <div>
                   <h3 className="text-white font-bold text-lg leading-tight mb-1 group-hover:text-brand-bright transition-colors">{expert.name}</h3>
                   <div className="flex items-center gap-1 text-xs text-brand-gray mb-1">
                      {expert.verified && <BadgeCheck size={14} className="text-blue-400" />}
                      <span>{expert.role}</span>
                   </div>
                   <div className="text-[10px] text-brand-gray/60 font-mono">{expert.company}</div>
                </div>
              </div>

              {/* Stats Row */}
              <div className="flex items-center justify-between bg-brand-black/40 rounded-lg p-2 mb-4 border border-white/5">
                 <div className="flex items-center gap-1.5 px-2">
                    <Star size={14} className="text-yellow-500 fill-yellow-500" />
                    <span className="text-sm font-bold text-white">{expert.rating}</span>
                    <span className="text-[10px] text-brand-gray">({expert.reviewCount})</span>
                 </div>
                 <div className="w-px h-6 bg-white/10"></div>
                 <div className="flex items-center gap-1.5 px-2">
                    <Clock size={14} className="text-brand-gray" />
                    <span className="text-sm font-bold text-white">{expert.experienceYears}</span>
                    <span className="text-[10px] text-brand-gray">{t.years}</span>
                 </div>
              </div>

              {/* Skills Tags */}
              <div className="flex flex-wrap gap-2 mb-6 h-14 content-start overflow-hidden">
                {expert.specialty.map((tag: string, i: number) => (
                  <span key={i} className={`text-[11px] px-2 py-1 rounded-md border transition-colors ${
                     aiMatchMode && assessmentResult?.roadmap.some(r => r.title.includes(tag)) 
                     ? 'bg-brand-red/20 text-brand-light border-brand-red/40'
                     : 'text-brand-gray bg-brand-black/40 border-white/5 group-hover:border-white/10'
                  }`}>
                    {tag}
                  </span>
                ))}
              </div>

              {/* Footer Actions */}
              <div className="mt-auto flex items-center gap-3">
                 <button 
                   onClick={() => setSelectedExpert(expert)}
                   className="flex-1 bg-white/5 hover:bg-white/10 text-white py-2.5 rounded-lg text-xs font-bold transition-colors border border-white/5"
                 >
                    {t.viewProfile}
                 </button>
                 <button 
                   onClick={() => { setSelectedExpert(expert); setTimeout(handleBookClick, 100); }}
                   className="flex-1 bg-brand-light hover:bg-white text-brand-black py-2.5 rounded-lg text-xs font-bold transition-colors shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                 >
                    <MessageSquare size={14} /> {t.connect}
                 </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* EXPERT DETAILS SLIDEOVER/MODAL */}
      {selectedExpert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
          <div className="absolute inset-0 bg-brand-black/90 backdrop-blur-sm" onClick={() => !isBooking && setSelectedExpert(null)}></div>
          
          <div className="relative w-full max-w-4xl bg-brand-dark border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
             {/* Close Button */}
             <button 
               onClick={() => setSelectedExpert(null)}
               className="absolute top-4 right-4 z-20 p-2 bg-brand-black/50 rounded-full text-white hover:bg-brand-red transition-colors"
             >
               <X size={20} />
             </button>

             {/* 1. Modal Header (Cover Image style) */}
             <div className="h-32 bg-gradient-to-r from-brand-wine to-brand-black relative">
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
             </div>
             
             <div className="px-8 pb-8 flex-1 overflow-y-auto">
                <div className="flex flex-col md:flex-row gap-6 -mt-12 mb-8">
                   <div className="shrink-0 relative">
                      <img src={selectedExpert.imageUrl} className="w-32 h-32 rounded-3xl border-4 border-brand-dark shadow-xl object-cover" alt={selectedExpert.name} />
                      <div className="absolute bottom-2 right-2 bg-brand-dark px-2 py-1 rounded-lg border border-white/10 flex items-center gap-1 shadow-lg">
                         <Star size={12} className="text-yellow-500 fill-yellow-500" />
                         <span className="text-xs font-bold text-white">{selectedExpert.rating}</span>
                      </div>
                   </div>
                   <div className="pt-14 md:pt-12">
                      <div className="flex items-center gap-2 mb-1">
                         <h2 className="text-2xl font-bold text-white">{selectedExpert.name}</h2>
                         {selectedExpert.verified && <BadgeCheck size={20} className="text-blue-400" />}
                      </div>
                      <p className="text-brand-bright font-medium">{selectedExpert.role} <span className="text-brand-gray">at {selectedExpert.company}</span></p>
                      <div className="flex flex-wrap gap-4 mt-3 text-sm text-brand-gray">
                         <div className="flex items-center gap-1.5"><MapPin size={14}/> Remote / Hybrid</div>
                         <div className="flex items-center gap-1.5"><Briefcase size={14}/> {selectedExpert.experienceYears} {t.years} exp</div>
                         <div className="flex items-center gap-1.5"><Globe2 size={14}/> {selectedExpert.languages.join(', ')}</div>
                      </div>
                   </div>
                   <div className="md:ml-auto pt-14 md:pt-12 flex flex-col items-end justify-center">
                      <div className="text-2xl font-bold text-white">{selectedExpert.currency}{selectedExpert.hourlyRate}<span className="text-sm font-normal text-brand-gray">{t.hr}</span></div>
                      <button 
                        onClick={handleBookClick}
                        className="mt-2 bg-brand-bright text-white px-6 py-2.5 rounded-xl font-bold hover:bg-brand-red transition-colors shadow-lg shadow-brand-red/20 w-full md:w-auto"
                      >
                         {t.book}
                      </button>
                   </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                   {/* Left Col */}
                   <div className="lg:col-span-2 space-y-8">
                      <section>
                         <h3 className="text-white font-bold text-lg mb-3 flex items-center gap-2">
                           <div className="w-1 h-5 bg-brand-red rounded-full"></div> {t.about}
                         </h3>
                         <p className="text-brand-gray leading-relaxed">{selectedExpert.bio}</p>
                      </section>

                      <section>
                         <h3 className="text-white font-bold text-lg mb-3 flex items-center gap-2">
                           <div className="w-1 h-5 bg-brand-red rounded-full"></div> {t.skills}
                         </h3>
                         <div className="flex flex-wrap gap-2">
                            {selectedExpert.specialty.map((skill, i) => (
                               <span key={i} className="px-3 py-1.5 bg-brand-dark border border-white/10 rounded-lg text-sm text-white">{skill}</span>
                            ))}
                         </div>
                      </section>
                   </div>

                   {/* Right Col */}
                   <div className="lg:col-span-1 space-y-4">
                      <div className="bg-brand-black/40 border border-white/5 rounded-2xl p-5">
                         <h4 className="text-white font-bold mb-4">{t.reviews}</h4>
                         <div className="space-y-4">
                            {[1,2].map((_, i) => (
                               <div key={i} className="text-sm">
                                  <div className="flex items-center gap-2 mb-1">
                                     <div className="flex text-yellow-500">
                                        {[...Array(5)].map((_, j) => <Star key={j} size={10} fill="currentColor" />)}
                                     </div>
                                     <span className="font-bold text-white">Great insights!</span>
                                  </div>
                                  <p className="text-brand-gray text-xs">"Helped us define our data strategy in just 2 sessions."</p>
                                  <p className="text-[10px] text-brand-gray/50 mt-1">2 days ago</p>
                               </div>
                            ))}
                         </div>
                      </div>
                   </div>
                </div>
             </div>
          </div>
        </div>
      )}

      {/* BOOKING MODAL */}
      {isBooking && selectedExpert && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
           <div className="bg-brand-dark border border-white/10 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200">
              <div className="p-4 border-b border-white/5 flex justify-between items-center bg-brand-black/50">
                 <h3 className="text-white font-bold flex items-center gap-2">
                    <CalendarCheck size={18} className="text-brand-bright" /> {t.bookingTitle}
                 </h3>
                 <button onClick={() => setIsBooking(false)} className="text-brand-gray hover:text-white"><X size={18}/></button>
              </div>
              
              <div className="p-6">
                 {bookingStep === 1 && (
                    <div className="space-y-6">
                       <div className="flex items-center gap-4 p-3 bg-white/5 rounded-xl border border-white/5">
                          <img src={selectedExpert.imageUrl} className="w-12 h-12 rounded-full object-cover" alt="" />
                          <div>
                             <div className="text-white font-bold">{selectedExpert.name}</div>
                             <div className="text-brand-bright text-xs">{selectedExpert.hourlyRate}{selectedExpert.currency} {t.hr}</div>
                          </div>
                       </div>
                       
                       <div>
                          <label className="block text-xs font-bold text-brand-gray uppercase mb-2">{t.briefing}</label>
                          <div className="relative">
                             <textarea 
                                value={generatedBrief}
                                onChange={(e) => setGeneratedBrief(e.target.value)}
                                className="w-full h-32 bg-brand-black border border-white/10 rounded-xl p-3 text-sm text-white focus:border-brand-bright focus:outline-none resize-none"
                                placeholder={isGeneratingBrief ? "AI is writing..." : "Describe your needs..."}
                             />
                             {isGeneratingBrief && (
                                <div className="absolute inset-0 flex items-center justify-center bg-brand-black/50 backdrop-blur-[1px] rounded-xl">
                                   <div className="flex items-center gap-2 text-brand-bright font-bold text-sm">
                                      <Sparkles size={16} className="animate-spin" /> Writing brief...
                                   </div>
                                </div>
                             )}
                          </div>
                          <p className="text-[10px] text-brand-gray mt-2 flex items-center gap-1.5">
                             <Sparkles size={10} className="text-brand-bright" /> {t.briefingDesc}
                          </p>
                       </div>

                       <button 
                         onClick={() => setBookingStep(2)}
                         className="w-full bg-brand-bright text-white py-3 rounded-xl font-bold hover:bg-brand-red transition-colors"
                       >
                          {t.confirm}
                       </button>
                    </div>
                 )}

                 {bookingStep === 2 && (
                    <div className="text-center py-8">
                       <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4 text-green-500">
                          <CheckCircle2 size={32} />
                       </div>
                       <h3 className="text-2xl font-bold text-white mb-2">{t.success}</h3>
                       <p className="text-brand-gray text-sm mb-6 max-w-xs mx-auto">{t.successDesc}</p>
                       <button 
                         onClick={() => { setIsBooking(false); setSelectedExpert(null); }}
                         className="bg-white/10 text-white px-8 py-2 rounded-lg text-sm font-bold hover:bg-white/20 transition-colors"
                       >
                          Close
                       </button>
                    </div>
                 )}
              </div>
           </div>
        </div>
      )}
    </div>
  );
};
