import React, { useState, Suspense, lazy } from 'react';
import { Sidebar } from './components/Sidebar';
import { FeatureId, AssessmentResult, Language } from './types';
import { ArrowRight, Sparkles, ShieldAlert } from 'lucide-react';

// Lazy load components for performance optimization (Code Splitting)
const Dashboard = lazy(() => import('./components/Dashboard').then(m => ({ default: m.Dashboard })));
const Assessment = lazy(() => import('./components/Assessment').then(m => ({ default: m.Assessment })));
const Roadmap = lazy(() => import('./components/Roadmap').then(m => ({ default: m.Roadmap })));
const ProjectTracking = lazy(() => import('./components/ProjectTracking').then(m => ({ default: m.ProjectTracking })));
const ExpertList = lazy(() => import('./components/ExpertList').then(m => ({ default: m.ExpertList })));
const ModelLab = lazy(() => import('./components/ModelLab').then(m => ({ default: m.ModelLab })));

// Loading Component
const GlobalLoader = () => (
  <div className="flex flex-col items-center justify-center h-full w-full bg-brand-black">
    <div className="relative w-20 h-20">
      <div className="absolute inset-0 border-t-2 border-brand-bright rounded-full animate-spin"></div>
      <div className="absolute inset-2 border-r-2 border-brand-wine rounded-full animate-spin-slow"></div>
    </div>
    <p className="mt-4 text-brand-gray text-sm font-mono animate-pulse">Initializing NexGen Core...</p>
  </div>
);

// Disclaimer Modal for Compliance
const DisclaimerModal = ({ onClose, language }: { onClose: () => void, language: Language }) => {
  const t = {
    en: {
      title: "Strategic Disclaimer",
      body: "NexGen DX utilizes advanced Artificial Intelligence (Google Gemini) to provide strategic recommendations, maturity assessments, and business modeling. While these insights are based on industry best practices, they are generated automatically and should be used as a reference for decision-making rather than absolute financial or legal advice. Please consult with verified human experts (available in our Expert Match feature) before making critical capital investments.",
      accept: "I Understand & Accept"
    },
    vi: {
      title: "Miễn Trừ Trách Nhiệm",
      body: "NexGen DX sử dụng Trí tuệ nhân tạo tiên tiến (Google Gemini) để cung cấp các khuyến nghị chiến lược, đánh giá mức độ trưởng thành và mô hình hóa kinh doanh. Mặc dù những thông tin chi tiết này dựa trên các thực tiễn tốt nhất của ngành, chúng được tạo tự động và chỉ nên được sử dụng làm tài liệu tham khảo cho việc ra quyết định thay vì lời khuyên tài chính hoặc pháp lý tuyệt đối. Vui lòng tham khảo ý kiến của các chuyên gia đã được xác minh (có sẵn trong tính năng Kết nối Chuyên gia) trước khi thực hiện các khoản đầu tư vốn quan trọng.",
      accept: "Tôi Hiểu & Chấp Nhận"
    }
  }[language];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm animate-fade-in">
      <div className="bg-brand-dark border border-white/10 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
        <div className="flex items-center gap-3 mb-4 text-brand-bright">
          <ShieldAlert size={32} />
          <h2 className="text-xl font-bold text-white">{t.title}</h2>
        </div>
        <p className="text-brand-gray text-sm leading-relaxed mb-6 border-l-2 border-white/10 pl-4">
          {t.body}
        </p>
        <button 
          onClick={onClose}
          className="w-full py-3 bg-brand-bright hover:bg-brand-red text-white font-bold rounded-xl transition-colors shadow-lg shadow-brand-red/20"
        >
          {t.accept}
        </button>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [currentFeature, setCurrentFeature] = useState<FeatureId>(FeatureId.DASHBOARD);
  const [assessmentResult, setAssessmentResult] = useState<AssessmentResult | null>(null);
  const [language, setLanguage] = useState<Language>('vi');
  const [expertSearchQuery, setExpertSearchQuery] = useState('');
  const [showDisclaimer, setShowDisclaimer] = useState(true);

  const handleAssessmentComplete = (result: AssessmentResult) => {
    setAssessmentResult(result);
    setCurrentFeature(FeatureId.DASHBOARD); // Return to dashboard to see results
  };

  const handleFindExpert = (query: string) => {
    setExpertSearchQuery(query);
    setCurrentFeature(FeatureId.EXPERTS);
  };

  const handleSidebarNavigate = (feature: FeatureId) => {
    setExpertSearchQuery(''); // Clear search when navigating via sidebar
    setCurrentFeature(feature);
  };

  const renderContent = () => {
    switch (currentFeature) {
      case FeatureId.DASHBOARD:
        return (
          <Dashboard 
            data={assessmentResult} 
            onStartAssessment={() => setCurrentFeature(FeatureId.ASSESSMENT)} 
            language={language}
          />
        );
      case FeatureId.ASSESSMENT:
        return <Assessment onComplete={handleAssessmentComplete} language={language} />;
      case FeatureId.ROADMAP:
        if (!assessmentResult) {
          return (
            <div className="flex flex-col items-center justify-center h-full text-center p-8 animate-fade-in">
              <div className="w-20 h-20 bg-brand-dark rounded-full flex items-center justify-center mb-6 border border-white/5">
                <Sparkles className="text-brand-gray" size={32} />
              </div>
              <h2 className="text-2xl text-white font-display font-bold mb-3">
                {language === 'vi' ? 'Chưa Có Lộ Trình' : 'No Roadmap Available'}
              </h2>
              <p className="text-brand-gray mb-8 max-w-md mx-auto">
                {language === 'vi' 
                  ? 'Hệ thống cần dữ liệu đầu vào để thiết kế lộ trình chuyển đổi số cá nhân hóa cho doanh nghiệp của bạn.' 
                  : 'The system needs input data to design a personalized digital transformation roadmap for your enterprise.'}
              </p>
              <button 
                onClick={() => setCurrentFeature(FeatureId.ASSESSMENT)}
                className="bg-brand-bright text-white px-8 py-3 rounded-full hover:bg-brand-red transition-all shadow-lg shadow-brand-red/20 flex items-center font-bold"
              >
                {language === 'vi' ? 'Bắt đầu Đánh giá' : 'Start Assessment'} <ArrowRight size={18} className="ml-2"/>
              </button>
            </div>
          )
        }
        return (
          <Roadmap 
            data={assessmentResult} 
            language={language} 
            onNavigateToAssessment={() => setCurrentFeature(FeatureId.ASSESSMENT)}
            onFindExpert={handleFindExpert}
          />
        );
      case FeatureId.PROJECTS:
        return <ProjectTracking language={language} />;
      case FeatureId.EXPERTS:
        return <ExpertList language={language} assessmentResult={assessmentResult} initialSearchTerm={expertSearchQuery} />;
      case FeatureId.MODELLAB:
        return <ModelLab language={language} />;
      default:
        return <div className="text-white p-10">Feature under construction</div>;
    }
  };

  return (
    <div className="flex h-screen bg-brand-black font-sans text-brand-gray overflow-hidden selection:bg-brand-red selection:text-white">
      {showDisclaimer && <DisclaimerModal onClose={() => setShowDisclaimer(false)} language={language} />}
      
      <Sidebar 
        currentFeature={currentFeature} 
        onNavigate={handleSidebarNavigate} 
        language={language}
        setLanguage={setLanguage}
      />
      <main className="flex-1 relative overflow-hidden flex flex-col">
        {/* Abstract Background Element */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-wine/10 rounded-full blur-[120px] pointer-events-none translate-x-1/4 -translate-y-1/4"></div>
        <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-brand-dark/20 rounded-full blur-[80px] pointer-events-none -translate-x-1/4 translate-y-1/4"></div>
        
        <Suspense fallback={<GlobalLoader />}>
          {renderContent()}
        </Suspense>
      </main>
    </div>
  );
};

export default App;