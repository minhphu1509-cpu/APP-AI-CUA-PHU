
export type Language = 'en' | 'vi';

export enum FeatureId {
  DASHBOARD = 'DASHBOARD',
  ASSESSMENT = 'ASSESSMENT',
  ROADMAP = 'ROADMAP',
  PROJECTS = 'PROJECTS',
  EXPERTS = 'EXPERTS',
  MODELLAB = 'MODELLAB'
}

export interface AssessmentScores {
  data: number;
  technology: number;
  process: number;
  people: number;
  strategy: number;
}

export interface RoadmapItem {
  phase: 'Short Term' | 'Medium Term' | 'Long Term';
  title: string;
  description: string;
  kpi: string;
}

export interface AssessmentResult {
  industry?: string;
  scores: AssessmentScores;
  summary: string;
  roadmap: RoadmapItem[];
}

export interface ExpertProfile {
  id: string;
  name: string;
  role: string;
  company: string;
  specialty: string[];
  rating: number;
  reviewCount: number;
  hourlyRate: number;
  currency: string;
  imageUrl: string;
  available: boolean;
  bio: string;
  languages: string[];
  experienceYears: number;
  verified: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

// Model Lab Types
export interface BusinessModelCanvas {
  keyPartners: string[];
  keyActivities: string[];
  keyResources: string[];
  valuePropositions: string[];
  customerRelationships: string[];
  channels: string[];
  customerSegments: string[];
  costStructure: string[];
  revenueStreams: string[];
}

export interface SWOT {
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  threats: string[];
}

export interface FinancialParams {
  initialUsers: number;
  monthlyGrowth: number; // percentage
  price: number;
  churnRate: number; // percentage
  costPerAcquisition: number;
}

export interface SimulationResult {
  canvas: BusinessModelCanvas;
  swot: SWOT;
  params: FinancialParams;
  name: string;
  description: string;
}
