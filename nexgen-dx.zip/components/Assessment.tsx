import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Sparkles, Building2, ShoppingCart, Landmark, Stethoscope, Factory, Check, Target, ChevronRight, Briefcase, Users } from 'lucide-react';
import { analyzeAssessment, AssessmentContext } from '../services/geminiService';
import { AssessmentResult, Language } from '../types';

interface AssessmentProps {
  onComplete: (result: AssessmentResult) => void;
  language: Language;
}

const INDUSTRIES = [
  { id: 'retail', label: 'Retail & E-commerce', icon: ShoppingCart },
  { id: 'finance', label: 'Finance & Banking', icon: Landmark },
  { id: 'manufacturing', label: 'Manufacturing', icon: Factory },
  { id: 'healthcare', label: 'Healthcare', icon: Stethoscope },
  { id: 'technology', label: 'Technology & SaaS', icon: Building2 },
];

const COMPANY_SIZES = [
  { id: 'startup', label: 'Startup (< 50)' },
  { id: 'sme', label: 'SME (50 - 500)' },
  { id: 'enterprise', label: 'Enterprise (500+)' },
];

const ROLES = [
  { id: 'c-level', label: 'C-Level (CEO, CTO, CIO)' },
  { id: 'manager', label: 'Head of Dept / Manager' },
  { id: 'specialist', label: 'Specialist / Consultant' },
];

// Richer data structure for questions
const DIMENSIONS_EN = [
  {
    id: 'data',
    category: 'Data Intelligence',
    question: "How does your organization utilize data for decision making?",
    tags: ["Data Silos", "Data Quality", "Real-time Analytics", "Governance", "AI Readiness"],
    options: [
      { val: 1, text: "Ad-hoc: Minimal data collection, manual spreadsheets." },
      { val: 2, text: "Siloed: Reports exist but departments don't share data." },
      { val: 3, text: "Managed: Centralized dashboard for operational tracking." },
      { val: 4, text: "Integrated: Predictive analytics drives key strategies." },
      { val: 5, text: "Optimized: AI-first culture with automated decision loops." }
    ]
  },
  {
    id: 'technology',
    category: 'Technology Core',
    question: "Describe the state of your IT infrastructure.",
    tags: ["Legacy Systems", "Cloud Migration", "Cybersecurity", "Integration Costs", "Mobile First"],
    options: [
      { val: 1, text: "Legacy: On-premise monoliths, difficult to change." },
      { val: 2, text: "Hybrid: Mix of legacy and ad-hoc cloud tools." },
      { val: 3, text: "Cloud-Enabled: Lift-and-shift completed, basic APIs." },
      { val: 4, text: "Modern: Cloud-native, microservices, robust APIs." },
      { val: 5, text: "Cutting Edge: Serverless, event-driven, auto-scaling." }
    ]
  },
  {
    id: 'process',
    category: 'Operations & Process',
    question: "To what extent are your workflows automated?",
    tags: ["Manual Entry", "Paperwork", "Bottlenecks", "Lack of Standards", "Compliance"],
    options: [
      { val: 1, text: "Manual: Heavy reliance on paper and email." },
      { val: 2, text: "Digitized: Basic digital tools (Office, basic ERP)." },
      { val: 3, text: "Automated: RPA handles repetitive tasks." },
      { val: 4, text: "Integrated: End-to-end workflow orchestration." },
      { val: 5, text: "Intelligent: Self-optimizing processes via AI." }
    ]
  },
  {
    id: 'people',
    category: 'People & Culture',
    question: "How would you describe your organization's digital culture?",
    tags: ["Skills Gap", "Resistance to Change", "Remote Work", "Leadership Buy-in", "Training"],
    options: [
      { val: 1, text: "Resistant: Skepticism towards new technology." },
      { val: 2, text: "Siloed: IT Dept drives tech, others follow reluctantly." },
      { val: 3, text: "Aligned: Digital training exists, adoption is mixed." },
      { val: 4, text: "Agile: Cross-functional teams, continuous learning." },
      { val: 5, text: "Innovative: Digital is DNA. Everyone creates value." }
    ]
  },
  {
    id: 'strategy',
    category: 'Strategic Vision',
    question: "How central is digital transformation to your business strategy?",
    tags: ["Budget Constraints", "ROI Definition", "Competitive Pressure", "New Business Models", "Customer Exp"],
    options: [
      { val: 1, text: "None: No specific digital strategy." },
      { val: 2, text: "Support: Digital is viewed as an IT cost center." },
      { val: 3, text: "Roadmap: 1-2 year plan for system upgrades." },
      { val: 4, text: "Core: Digital is a key pillar of growth." },
      { val: 5, text: "Disruptive: Business model is platform/ecosystem based." }
    ]
  }
];

// Vietnamese translation
const DIMENSIONS_VI = [
  {
    id: 'data',
    category: 'Trí tuệ Dữ liệu',
    question: "Tổ chức của bạn sử dụng dữ liệu để ra quyết định như thế nào?",
    tags: ["Dữ liệu rời rạc", "Chất lượng dữ liệu", "Phân tích thời gian thực", "Quản trị dữ liệu", "Sẵn sàng cho AI"],
    options: [
      { val: 1, text: "Tự phát: Thu thập tối thiểu, dùng Excel thủ công." },
      { val: 2, text: "Rời rạc: Có báo cáo nhưng các phòng ban không chia sẻ." },
      { val: 3, text: "Được quản lý: Dashboard tập trung theo dõi vận hành." },
      { val: 4, text: "Tích hợp: Phân tích dự đoán định hướng chiến lược." },
      { val: 5, text: "Tối ưu hóa: Văn hóa AI-first, ra quyết định tự động." }
    ]
  },
  {
    id: 'technology',
    category: 'Cốt lõi Công nghệ',
    question: "Mô tả trạng thái hạ tầng CNTT hiện tại.",
    tags: ["Hệ thống cũ", "Chuyển đổi Cloud", "An ninh mạng", "Chi phí tích hợp", "Mobile First"],
    options: [
      { val: 1, text: "Lạc hậu: Hệ thống tại chỗ cũ kỹ, khó thay đổi." },
      { val: 2, text: "Lai (Hybrid): Kết hợp cũ và các công cụ cloud tự phát." },
      { val: 3, text: "Cloud hóa: Đã đưa lên mây, API cơ bản." },
      { val: 4, text: "Hiện đại: Cloud-native, microservices, API mạnh mẽ." },
      { val: 5, text: "Tiên phong: Serverless, hướng sự kiện, tự mở rộng." }
    ]
  },
  {
    id: 'process',
    category: 'Vận hành & Quy trình',
    question: "Quy trình làm việc được tự động hóa đến mức nào?",
    tags: ["Nhập liệu thủ công", "Giấy tờ", "Nút thắt cổ chai", "Thiếu quy chuẩn", "Tuân thủ"],
    options: [
      { val: 1, text: "Thủ công: Phụ thuộc nhiều vào giấy tờ, email." },
      { val: 2, text: "Số hóa: Công cụ cơ bản (Office, ERP cơ bản)." },
      { val: 3, text: "Tự động: RPA xử lý các tác vụ lặp lại." },
      { val: 4, text: "Tích hợp: Điều phối quy trình xuyên suốt." },
      { val: 5, text: "Thông minh: Quy trình tự tối ưu bằng AI." }
    ]
  },
  {
    id: 'people',
    category: 'Con người & Văn hóa',
    question: "Bạn mô tả văn hóa số của tổ chức như thế nào?",
    tags: ["Thiếu kỹ năng", "Ngại thay đổi", "Làm việc từ xa", "Lãnh đạo cam kết", "Đào tạo"],
    options: [
      { val: 1, text: "Đề kháng: Hoài nghi với công nghệ mới." },
      { val: 2, text: "Rời rạc: IT thúc đẩy, các bên khác miễn cưỡng." },
      { val: 3, text: "Đồng thuận: Có đào tạo, mức độ áp dụng chưa đều." },
      { val: 4, text: "Linh hoạt (Agile): Hợp tác chéo, học tập liên tục." },
      { val: 5, text: "Đổi mới: Kỹ thuật số là DNA. Ai cũng tạo giá trị." }
    ]
  },
  {
    id: 'strategy',
    category: 'Tầm nhìn Chiến lược',
    question: "Chuyển đổi số quan trọng thế nào trong chiến lược kinh doanh?",
    tags: ["Ngân sách hạn hẹp", "Định nghĩa ROI", "Áp lực cạnh tranh", "Mô hình kinh doanh mới", "Trải nghiệm khách hàng"],
    options: [
      { val: 1, text: "Không: Không có chiến lược số cụ thể." },
      { val: 2, text: "Hỗ trợ: Kỹ thuật số là trung tâm chi phí (Cost center)." },
      { val: 3, text: "Lộ trình: Kế hoạch 1-2 năm nâng cấp hệ thống." },
      { val: 4, text: "Cốt lõi: Trụ cột chính của tăng trưởng." },
      { val: 5, text: "Đột phá: Mô hình kinh doanh dựa trên nền tảng/hệ sinh thái." }
    ]
  }
];

export const Assessment: React.FC<AssessmentProps> = ({ onComplete, language }) => {
  const [step, setStep] = useState<'profile' | 'questions'>('profile');
  
  // Profile State
  const [industry, setIndustry] = useState('');
  const [companySize, setCompanySize] = useState('');
  const [role, setRole] = useState('');

  // Assessment State
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [focusAreas, setFocusAreas] = useState<Record<string, string[]>>({}); // Multi-select tags per question
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const DIMENSIONS = language === 'vi' ? DIMENSIONS_VI : DIMENSIONS_EN;
  const currentDim = DIMENSIONS[currentQIndex];

  const t = {
    en: {
      profileTitle: "Enterprise Profile",
      profileDesc: "Help NexGen AI calibrate benchmarks for your specific context.",
      industry: "Industry Sector",
      size: "Company Size",
      role: "Your Role",
      start: "Start Diagnostic",
      analyzingTitle: "Generating Strategic Blueprint",
      analyzingDesc: "NexGen AI is synthesizing your maturity data, industry benchmarks, and focus areas...",
      next: "Next Dimension",
      finish: "Generate Report",
      focusTitle: "Key Challenges / Priorities",
      focusDesc: "Select up to 3 focus areas for this dimension.",
      maturityTitle: "Maturity Level"
    },
    vi: {
      profileTitle: "Hồ sơ Doanh nghiệp",
      profileDesc: "Giúp NexGen AI hiệu chỉnh tiêu chuẩn đánh giá cho ngữ cảnh của bạn.",
      industry: "Lĩnh vực Hoạt động",
      size: "Quy mô Doanh nghiệp",
      role: "Vai trò của Bạn",
      start: "Bắt đầu Chẩn đoán",
      analyzingTitle: "Đang Lập Bản Đồ Chiến Lược",
      analyzingDesc: "NexGen AI đang tổng hợp dữ liệu trưởng thành, điểm chuẩn ngành và các ưu tiên của bạn...",
      next: "Tiếp theo",
      finish: "Xuất Báo cáo",
      focusTitle: "Thách thức / Ưu tiên Chính",
      focusDesc: "Chọn tối đa 3 điểm trọng tâm.",
      maturityTitle: "Mức độ Trưởng thành"
    }
  }[language];

  const toggleFocusArea = (tag: string) => {
    setFocusAreas(prev => {
      const current = prev[currentDim.id] || [];
      if (current.includes(tag)) {
        return { ...prev, [currentDim.id]: current.filter(t => t !== tag) };
      }
      if (current.length >= 3) return prev; // Max 3
      return { ...prev, [currentDim.id]: [...current, tag] };
    });
  };

  const handleNext = async () => {
    if (currentQIndex < DIMENSIONS.length - 1) {
      setCurrentQIndex(prev => prev + 1);
    } else {
      // Submit
      setIsAnalyzing(true);
      const context: AssessmentContext = {
        industry,
        companySize,
        role,
        answers,
        focusAreas
      };
      
      try {
        const result = await analyzeAssessment(context, language);
        onComplete(result);
      } catch (error) {
        console.error("Assessment failed", error);
        alert("Analysis failed. Please try again.");
        setIsAnalyzing(false);
      }
    }
  };

  if (isAnalyzing) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 text-center animate-fade-in relative overflow-hidden">
        {/* Abstract Background Animation */}
        <div className="absolute inset-0 bg-brand-black">
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-brand-red/10 rounded-full blur-[100px] animate-pulse"></div>
        </div>
        
        <div className="relative z-10">
          <div className="w-24 h-24 mx-auto bg-gradient-to-tr from-brand-wine to-brand-red rounded-2xl flex items-center justify-center mb-8 relative shadow-[0_0_50px_rgba(229,56,59,0.5)]">
            <div className="absolute inset-0 border-2 border-white/20 rounded-2xl animate-ping opacity-20"></div>
            <Sparkles className="text-white w-10 h-10 animate-spin-slow" />
          </div>
          <h2 className="text-4xl font-display font-bold text-white mb-4 tracking-tight">{t.analyzingTitle}</h2>
          <p className="text-brand-gray max-w-lg mx-auto text-lg leading-relaxed">{t.analyzingDesc}</p>
          
          <div className="mt-12 flex justify-center gap-2">
            <div className="w-2 h-2 bg-brand-bright rounded-full animate-bounce delay-0"></div>
            <div className="w-2 h-2 bg-brand-bright rounded-full animate-bounce delay-150"></div>
            <div className="w-2 h-2 bg-brand-bright rounded-full animate-bounce delay-300"></div>
          </div>
        </div>
      </div>
    );
  }

  /* ---------------- STEP 1: PROFILE ---------------- */
  if (step === 'profile') {
    return (
      <div className="max-w-5xl mx-auto py-12 px-6 animate-fade-in-up">
        <div className="text-center mb-12">
          <div className="inline-block p-3 rounded-full bg-brand-white/5 border border-white/10 mb-4">
             <Briefcase className="text-brand-bright w-6 h-6" />
          </div>
          <h2 className="text-4xl font-display font-bold text-white mb-3">{t.profileTitle}</h2>
          <p className="text-brand-gray text-lg max-w-2xl mx-auto">{t.profileDesc}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {/* Industry Selection */}
          <div className="space-y-4">
            <h3 className="text-brand-bright text-sm font-bold uppercase tracking-wider flex items-center gap-2">
              <Building2 size={16}/> {t.industry}
            </h3>
            <div className="space-y-2">
              {INDUSTRIES.map((ind) => (
                <button
                  key={ind.id}
                  onClick={() => setIndustry(ind.label)}
                  className={`w-full text-left p-4 rounded-xl border transition-all flex items-center justify-between group ${
                    industry === ind.label 
                      ? 'bg-brand-red text-white border-brand-bright shadow-lg shadow-brand-red/20' 
                      : 'bg-brand-dark/50 border-white/5 text-brand-gray hover:bg-white/5 hover:border-white/20'
                  }`}
                >
                  <span className="font-medium">{ind.label}</span>
                  {industry === ind.label && <CheckCircle2 size={18} />}
                </button>
              ))}
            </div>
          </div>

          {/* Size Selection */}
          <div className="space-y-4">
            <h3 className="text-brand-bright text-sm font-bold uppercase tracking-wider flex items-center gap-2">
              <Users size={16}/> {t.size}
            </h3>
            <div className="space-y-2">
              {COMPANY_SIZES.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setCompanySize(s.label)}
                  className={`w-full text-left p-4 rounded-xl border transition-all flex items-center justify-between ${
                    companySize === s.label 
                      ? 'bg-brand-red text-white border-brand-bright shadow-lg shadow-brand-red/20' 
                      : 'bg-brand-dark/50 border-white/5 text-brand-gray hover:bg-white/5 hover:border-white/20'
                  }`}
                >
                  <span className="font-medium">{s.label}</span>
                  {companySize === s.label && <CheckCircle2 size={18} />}
                </button>
              ))}
            </div>
          </div>

          {/* Role Selection */}
          <div className="space-y-4">
            <h3 className="text-brand-bright text-sm font-bold uppercase tracking-wider flex items-center gap-2">
              <Target size={16}/> {t.role}
            </h3>
            <div className="space-y-2">
              {ROLES.map((r) => (
                <button
                  key={r.id}
                  onClick={() => setRole(r.label)}
                  className={`w-full text-left p-4 rounded-xl border transition-all flex items-center justify-between ${
                    role === r.label 
                      ? 'bg-brand-red text-white border-brand-bright shadow-lg shadow-brand-red/20' 
                      : 'bg-brand-dark/50 border-white/5 text-brand-gray hover:bg-white/5 hover:border-white/20'
                  }`}
                >
                  <span className="font-medium">{r.label}</span>
                  {role === r.label && <CheckCircle2 size={18} />}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex justify-center pt-8 border-t border-white/5">
          <button
            onClick={() => setStep('questions')}
            disabled={!industry || !companySize || !role}
            className="group px-12 py-4 bg-brand-bright text-white rounded-full font-bold text-lg shadow-xl shadow-brand-red/30 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-brand-red transition-all flex items-center gap-3"
          >
            {t.start} 
            <ChevronRight size={20} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    );
  }

  /* ---------------- STEP 2: QUESTIONS ---------------- */
  const progress = ((currentQIndex + 1) / DIMENSIONS.length) * 100;
  
  return (
    <div className="max-w-6xl mx-auto py-8 px-6 h-full flex flex-col">
      {/* Header & Progress */}
      <div className="mb-8">
        <div className="flex justify-between items-end mb-4">
          <div>
            <h2 className="text-3xl font-display font-bold text-white">{currentDim.category}</h2>
            <p className="text-brand-gray mt-1 text-sm font-mono uppercase tracking-wider">
               {language === 'vi' ? 'Trụ cột' : 'Dimension'} 0{currentQIndex + 1} / 0{DIMENSIONS.length}
            </p>
          </div>
          <div className="text-right">
             <div className="text-xs text-brand-gray mb-1">{industry} • {companySize}</div>
             <div className="text-xs text-brand-bright font-bold">{role}</div>
          </div>
        </div>
        <div className="h-1.5 w-full bg-brand-dark rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-brand-bright to-brand-crimson transition-all duration-700 ease-out" 
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Main Content Split Pane */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 pb-20">
        
        {/* Left Col: Maturity Question */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-brand-dark/40 border border-white/5 p-6 rounded-2xl backdrop-blur-sm">
            <h3 className="text-xl text-white font-medium mb-6 leading-relaxed">
               <span className="text-brand-bright mr-2">Q.</span>{currentDim.question}
            </h3>
            
            <div className="space-y-3">
              {currentDim.options.map((opt) => (
                <button
                  key={opt.val}
                  onClick={() => setAnswers(prev => ({ ...prev, [currentDim.id]: opt.text }))}
                  role="radio"
                  aria-checked={answers[currentDim.id] === opt.text}
                  className={`w-full text-left p-4 rounded-xl border transition-all duration-200 flex items-center gap-4 group focus:outline-none focus:ring-2 focus:ring-brand-bright/50 ${
                    answers[currentDim.id] === opt.text
                      ? 'bg-brand-wine/20 border-brand-red text-white shadow-inner'
                      : 'bg-brand-black/40 border-white/5 text-brand-gray hover:border-brand-gray/30 hover:bg-white/5'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border ${
                     answers[currentDim.id] === opt.text
                     ? 'bg-brand-red border-brand-bright text-white'
                     : 'bg-transparent border-white/20 text-brand-gray group-hover:border-white/50'
                  }`}>
                    {opt.val}
                  </div>
                  <span className="text-sm md:text-base leading-snug">{opt.text}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Context / Focus Areas */}
        <div className="lg:col-span-5 space-y-6">
           <div className="bg-gradient-to-br from-brand-dark to-brand-black border border-white/10 p-6 rounded-2xl h-full flex flex-col">
              <div className="mb-6">
                <h3 className="text-white font-bold text-lg mb-1 flex items-center gap-2">
                   <Target size={18} className="text-brand-bright" /> {t.focusTitle}
                </h3>
                <p className="text-xs text-brand-gray">{t.focusDesc}</p>
              </div>

              <div className="flex flex-wrap gap-2 mb-auto">
                 {currentDim.tags.map(tag => {
                    const isSelected = (focusAreas[currentDim.id] || []).includes(tag);
                    return (
                      <button
                        key={tag}
                        onClick={() => toggleFocusArea(tag)}
                        className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all ${
                          isSelected
                            ? 'bg-brand-bright text-white border-brand-bright shadow-lg shadow-brand-red/20 scale-105'
                            : 'bg-white/5 text-brand-gray border-white/5 hover:bg-white/10 hover:border-white/20'
                        }`}
                      >
                        {tag} {isSelected && <Check size={12} className="inline ml-1"/>}
                      </button>
                    )
                 })}
              </div>

              {/* Tips or Insight */}
              <div className="mt-8 pt-6 border-t border-white/5">
                 <div className="flex gap-3">
                    <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center shrink-0">
                       <Sparkles size={20} className="text-blue-400" />
                    </div>
                    <div>
                       <p className="text-xs text-blue-300 font-bold uppercase mb-1">AI Context</p>
                       <p className="text-xs text-brand-gray leading-relaxed">
                          By selecting "{focusAreas[currentDim.id]?.[0] || '...'}", NexGen will prioritize solutions that address this specific bottleneck in the {currentDim.category} roadmap.
                       </p>
                    </div>
                 </div>
              </div>
           </div>
        </div>

      </div>

      {/* Footer Navigation */}
      <div className="fixed bottom-0 left-64 right-0 p-6 bg-brand-black/90 backdrop-blur border-t border-white/5 flex justify-end z-20">
         <div className="max-w-6xl w-full mx-auto flex justify-end">
            <button
              onClick={handleNext}
              disabled={!answers[currentDim.id]}
              className={`flex items-center space-x-3 px-10 py-4 rounded-full font-bold text-lg transition-all duration-300 ${
                answers[currentDim.id]
                  ? 'bg-brand-bright text-white hover:bg-brand-red shadow-xl shadow-brand-red/20 hover:translate-x-1' 
                  : 'bg-brand-dark text-brand-gray cursor-not-allowed opacity-50'
              }`}
            >
              <span>{currentQIndex === DIMENSIONS.length - 1 ? t.finish : t.next}</span>
              <ArrowRight size={20} />
            </button>
         </div>
      </div>
    </div>
  );
};