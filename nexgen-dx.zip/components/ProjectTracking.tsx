
import React, { useState } from 'react';
import { 
  FolderKanban, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  MoreHorizontal, 
  Plus, 
  Calendar,
  Users,
  ChevronRight,
  TrendingUp,
  BarChart3,
  Layers,
  ArrowRight
} from 'lucide-react';
import { Language } from '../types';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';

interface ProjectTrackingProps {
  language: Language;
}

interface ProjectTask {
  id: string;
  title: string;
  assignee: string;
  status: 'done' | 'in_progress' | 'todo';
  dueDate: string;
}

interface Project {
  id: string;
  name: string;
  description: string;
  status: 'on_track' | 'at_risk' | 'delayed' | 'completed';
  progress: number;
  startDate: string;
  endDate: string;
  tasks: ProjectTask[];
  team: string[]; // URLs
  category: string;
}

const MOCK_PROJECTS: Project[] = [
  {
    id: '1',
    name: 'Cloud Migration Phase 1',
    description: 'Migrating legacy ERP to AWS Cloud infrastructure with focus on security compliance.',
    status: 'on_track',
    progress: 75,
    startDate: '2023-09-01',
    endDate: '2023-12-15',
    category: 'Infrastructure',
    team: [
      'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=100&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=100&auto=format&fit=crop'
    ],
    tasks: [
      { id: 't1', title: 'Database Schema Audit', assignee: 'Sarah Chen', status: 'done', dueDate: '2023-10-10' },
      { id: 't2', title: 'Setup VPC Peering', assignee: 'Marcus R.', status: 'done', dueDate: '2023-10-25' },
      { id: 't3', title: 'Data Migration Scripts', assignee: 'Sarah Chen', status: 'in_progress', dueDate: '2023-11-20' },
      { id: 't4', title: 'Final Cutover Rehearsal', assignee: 'Team', status: 'todo', dueDate: '2023-12-01' },
    ]
  },
  {
    id: '2',
    name: 'AI Customer Support Bot',
    description: 'Implementing GenAI chatbot for L1 support automation.',
    status: 'at_risk',
    progress: 30,
    startDate: '2023-10-01',
    endDate: '2024-02-28',
    category: 'Innovation',
    team: [
      'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?q=80&w=100&auto=format&fit=crop'
    ],
    tasks: [
      { id: 't1', title: 'Requirement Gathering', assignee: 'Aisha P.', status: 'done', dueDate: '2023-10-15' },
      { id: 't2', title: 'Model Selection (LLM)', assignee: 'Aisha P.', status: 'in_progress', dueDate: '2023-11-05' },
      { id: 't3', title: 'Integration with CRM', assignee: 'Dev Team', status: 'todo', dueDate: '2023-12-10' },
    ]
  },
  {
    id: '3',
    name: 'Data Warehouse Setup',
    description: 'Centralizing data from Sales, Marketing, and Operations.',
    status: 'completed',
    progress: 100,
    startDate: '2023-06-01',
    endDate: '2023-09-30',
    category: 'Data',
    team: [
      'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=100&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=100&auto=format&fit=crop'
    ],
    tasks: [
      { id: 't1', title: 'Snowflake Configuration', assignee: 'James F.', status: 'done', dueDate: '2023-06-15' },
      { id: 't2', title: 'ETL Pipeline Dev', assignee: 'Robert K.', status: 'done', dueDate: '2023-08-01' },
      { id: 't3', title: 'Dashboard Creation', assignee: 'Robert K.', status: 'done', dueDate: '2023-09-15' },
    ]
  }
];

export const ProjectTracking: React.FC<ProjectTrackingProps> = ({ language }) => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const t = {
    en: {
      title: "Project Execution Center",
      subtitle: "Monitor progress, manage risks, and collaborate with experts.",
      createBtn: "New Project",
      activeProjects: "Active Projects",
      completedProjects: "Completed",
      totalBudget: "Total Budget Used",
      resourceUtil: "Resource Utilization",
      status: {
        on_track: "On Track",
        at_risk: "At Risk",
        delayed: "Delayed",
        completed: "Completed"
      },
      headers: {
        task: "Task Name",
        assignee: "Assignee",
        due: "Due Date",
        status: "Status"
      },
      details: "Project Details",
      back: "Back to Dashboard",
      tasks: "Task List",
      timeline: "Timeline"
    },
    vi: {
      title: "Trung Tâm Điều Hành Dự Án",
      subtitle: "Theo dõi tiến độ, quản lý rủi ro và cộng tác với chuyên gia.",
      createBtn: "Dự Án Mới",
      activeProjects: "Dự Án Đang Chạy",
      completedProjects: "Đã Hoàn Thành",
      totalBudget: "Ngân Sách Đã Dùng",
      resourceUtil: "Sử Dụng Nguồn Lực",
      status: {
        on_track: "Đúng Tiến Độ",
        at_risk: "Rủi Ro",
        delayed: "Chậm Trễ",
        completed: "Hoàn Thành"
      },
      headers: {
        task: "Tên Tác Vụ",
        assignee: "Người Phụ Trách",
        due: "Hạn Chót",
        status: "Trạng Thái"
      },
      details: "Chi Tiết Dự Án",
      back: "Quay lại",
      tasks: "Danh Sách Công Việc",
      timeline: "Dòng Thời Gian"
    }
  }[language];

  const getStatusColor = (status: Project['status']) => {
    switch(status) {
      case 'on_track': return 'text-green-400 bg-green-500/10 border-green-500/20';
      case 'at_risk': return 'text-orange-400 bg-orange-500/10 border-orange-500/20';
      case 'delayed': return 'text-red-400 bg-red-500/10 border-red-500/20';
      case 'completed': return 'text-blue-400 bg-blue-500/10 border-blue-500/20';
      default: return 'text-gray-400';
    }
  };

  const activityData = [
    { name: 'Mon', hours: 24 },
    { name: 'Tue', hours: 35 },
    { name: 'Wed', hours: 42 },
    { name: 'Thu', hours: 38 },
    { name: 'Fri', hours: 30 },
    { name: 'Sat', hours: 10 },
    { name: 'Sun', hours: 5 },
  ];

  if (selectedProject) {
    return (
      <div className="h-full flex flex-col bg-brand-black p-6 md:p-8 overflow-y-auto">
        {/* Detail Header */}
        <div className="flex items-center gap-4 mb-8">
          <button 
            onClick={() => setSelectedProject(null)}
            className="p-2 rounded-full bg-brand-dark border border-white/10 hover:bg-white/10 text-brand-gray hover:text-white transition-colors"
          >
            <ChevronRight size={20} className="rotate-180" />
          </button>
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-3">
              {selectedProject.name}
              <span className={`text-xs px-2 py-0.5 rounded border font-mono uppercase ${getStatusColor(selectedProject.status)}`}>
                {t.status[selectedProject.status]}
              </span>
            </h2>
            <p className="text-brand-gray text-sm">{selectedProject.description}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Progress Card */}
          <div className="bg-brand-dark border border-white/5 rounded-2xl p-6">
            <h3 className="text-white font-bold mb-4 flex items-center gap-2">
              <TrendingUp size={18} className="text-brand-bright" /> Progress
            </h3>
            <div className="relative pt-4">
              <div className="flex justify-between text-sm text-brand-gray mb-2">
                 <span>Completion</span>
                 <span className="text-white font-bold">{selectedProject.progress}%</span>
              </div>
              <div className="w-full h-3 bg-brand-black rounded-full overflow-hidden border border-white/5">
                 <div className="h-full bg-gradient-to-r from-brand-bright to-brand-red" style={{ width: `${selectedProject.progress}%` }}></div>
              </div>
              <p className="mt-4 text-xs text-brand-gray">
                 Timeline: <span className="text-white">{selectedProject.startDate}</span> to <span className="text-white">{selectedProject.endDate}</span>
              </p>
            </div>
          </div>

          {/* Team Card */}
          <div className="bg-brand-dark border border-white/5 rounded-2xl p-6">
            <h3 className="text-white font-bold mb-4 flex items-center gap-2">
               <Users size={18} className="text-brand-bright" /> Team
            </h3>
            <div className="flex -space-x-3 mb-6">
              {selectedProject.team.map((avatar, i) => (
                <img key={i} src={avatar} className="w-10 h-10 rounded-full border-2 border-brand-dark" alt="Team" />
              ))}
              <button className="w-10 h-10 rounded-full border-2 border-brand-dark bg-brand-black flex items-center justify-center text-xs text-brand-gray hover:text-white hover:bg-white/5">
                 <Plus size={14} />
              </button>
            </div>
            <div className="space-y-2">
               <div className="flex justify-between text-xs text-brand-gray">
                  <span>Internal Members</span>
                  <span className="text-white">5</span>
               </div>
               <div className="flex justify-between text-xs text-brand-gray">
                  <span>External Experts</span>
                  <span className="text-white">2</span>
               </div>
            </div>
          </div>

          {/* Activity / Risk Card */}
          <div className="bg-brand-dark border border-white/5 rounded-2xl p-6">
             <h3 className="text-white font-bold mb-4 flex items-center gap-2">
               <AlertTriangle size={18} className={selectedProject.status === 'at_risk' ? 'text-orange-400' : 'text-green-400'} /> Risk Status
             </h3>
             {selectedProject.status === 'at_risk' ? (
               <div className="bg-orange-500/10 border border-orange-500/20 rounded-xl p-3">
                 <p className="text-orange-400 text-sm font-bold mb-1">High Risk Detected</p>
                 <p className="text-xs text-brand-gray">Technical integration delay with legacy system. Recommended action: Increase consultant hours.</p>
               </div>
             ) : (
               <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-3">
                 <p className="text-green-400 text-sm font-bold mb-1">Stable</p>
                 <p className="text-xs text-brand-gray">Project is proceeding according to the baseline schedule.</p>
               </div>
             )}
          </div>
        </div>

        {/* Task List */}
        <div className="bg-brand-dark/50 border border-white/5 rounded-2xl overflow-hidden flex-1">
          <div className="p-4 border-b border-white/5 bg-brand-black/20 flex justify-between items-center">
             <h3 className="font-bold text-white flex items-center gap-2">
               <Layers size={18} className="text-brand-bright" /> {t.tasks}
             </h3>
             <button className="text-xs bg-brand-bright text-white px-3 py-1.5 rounded-lg hover:bg-brand-red transition-colors">
                + Add Task
             </button>
          </div>
          <div className="overflow-x-auto">
             <table className="w-full text-left text-sm">
                <thead>
                   <tr className="border-b border-white/5 text-brand-gray">
                      <th className="p-4 font-medium">{t.headers.task}</th>
                      <th className="p-4 font-medium">{t.headers.assignee}</th>
                      <th className="p-4 font-medium">{t.headers.due}</th>
                      <th className="p-4 font-medium">{t.headers.status}</th>
                   </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                   {selectedProject.tasks.map(task => (
                      <tr key={task.id} className="hover:bg-white/5 transition-colors group">
                         <td className="p-4 text-white font-medium flex items-center gap-3">
                            <div className={`w-4 h-4 rounded border flex items-center justify-center ${task.status === 'done' ? 'bg-green-500 border-green-500' : 'border-white/20'}`}>
                               {task.status === 'done' && <CheckCircle2 size={10} className="text-brand-black" />}
                            </div>
                            {task.title}
                         </td>
                         <td className="p-4 text-brand-gray">{task.assignee}</td>
                         <td className="p-4 text-brand-gray font-mono text-xs">{task.dueDate}</td>
                         <td className="p-4">
                            <span className={`text-[10px] px-2 py-1 rounded font-bold uppercase ${
                               task.status === 'done' ? 'bg-green-500/10 text-green-400' : 
                               task.status === 'in_progress' ? 'bg-blue-500/10 text-blue-400' : 
                               'bg-white/5 text-brand-gray'
                            }`}>
                               {task.status === 'done' ? 'Done' : task.status === 'in_progress' ? 'In Progress' : 'To Do'}
                            </span>
                         </td>
                      </tr>
                   ))}
                </tbody>
             </table>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-brand-black p-6 md:p-8 overflow-y-auto relative">
       {/* Background Decoration */}
       <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-brand-bright/5 rounded-full blur-[100px] pointer-events-none"></div>

       <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 z-10">
         <div>
           <h1 className="text-3xl font-display font-bold text-white mb-2">{t.title}</h1>
           <p className="text-brand-gray">{t.subtitle}</p>
         </div>
         <button className="flex items-center gap-2 bg-brand-bright hover:bg-brand-red text-white px-5 py-2.5 rounded-xl font-bold transition-all shadow-lg shadow-brand-red/20">
            <Plus size={18} /> {t.createBtn}
         </button>
       </div>

       {/* Dashboard Metrics */}
       <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8 z-10">
          <div className="bg-brand-dark border border-white/5 p-4 rounded-xl">
             <div className="flex items-center gap-2 mb-2 text-brand-gray text-xs font-bold uppercase">
                <FolderKanban size={14} className="text-brand-bright"/> {t.activeProjects}
             </div>
             <div className="text-3xl font-display font-bold text-white">3</div>
          </div>
          <div className="bg-brand-dark border border-white/5 p-4 rounded-xl">
             <div className="flex items-center gap-2 mb-2 text-brand-gray text-xs font-bold uppercase">
                <CheckCircle2 size={14} className="text-green-400"/> {t.completedProjects}
             </div>
             <div className="text-3xl font-display font-bold text-white">12</div>
          </div>
          <div className="bg-brand-dark border border-white/5 p-4 rounded-xl">
             <div className="flex items-center gap-2 mb-2 text-brand-gray text-xs font-bold uppercase">
                <BarChart3 size={14} className="text-blue-400"/> {t.totalBudget}
             </div>
             <div className="text-3xl font-display font-bold text-white">$450k</div>
          </div>
          <div className="bg-brand-dark border border-white/5 p-4 rounded-xl relative overflow-hidden">
             <div className="flex items-center gap-2 mb-2 text-brand-gray text-xs font-bold uppercase relative z-10">
                <Users size={14} className="text-orange-400"/> {t.resourceUtil}
             </div>
             <div className="text-3xl font-display font-bold text-white relative z-10">87%</div>
             <ResponsiveContainer width="100%" height="100%" className="absolute bottom-0 right-0 opacity-20 translate-y-2">
                <BarChart data={activityData}>
                   <Bar dataKey="hours" fill="#e5383b" radius={[2,2,0,0]} />
                </BarChart>
             </ResponsiveContainer>
          </div>
       </div>

       {/* Active Projects Grid */}
       <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 z-10">
          {MOCK_PROJECTS.map(project => (
            <div 
              key={project.id}
              onClick={() => setSelectedProject(project)}
              className="bg-brand-dark/50 border border-white/5 hover:border-brand-bright/50 hover:bg-brand-dark transition-all duration-300 rounded-2xl p-6 cursor-pointer group flex flex-col h-full"
            >
               <div className="flex justify-between items-start mb-4">
                  <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded border ${getStatusColor(project.status)}`}>
                     {t.status[project.status]}
                  </span>
                  <div className="p-1 rounded-full hover:bg-white/10 text-brand-gray">
                     <MoreHorizontal size={16} />
                  </div>
               </div>

               <h3 className="text-xl font-bold text-white mb-2 group-hover:text-brand-bright transition-colors">{project.name}</h3>
               <p className="text-sm text-brand-gray mb-6 line-clamp-2 flex-1">{project.description}</p>

               <div className="space-y-4">
                  <div>
                     <div className="flex justify-between text-xs mb-1">
                        <span className="text-brand-gray">Progress</span>
                        <span className="text-white font-mono">{project.progress}%</span>
                     </div>
                     <div className="w-full h-1.5 bg-brand-black rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${project.status === 'at_risk' ? 'bg-orange-500' : 'bg-brand-bright'}`} 
                          style={{ width: `${project.progress}%` }}
                        ></div>
                     </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-white/5">
                     <div className="flex -space-x-2">
                        {project.team.map((img, i) => (
                           <img key={i} src={img} className="w-6 h-6 rounded-full border border-brand-dark" alt="" />
                        ))}
                        {project.team.length > 0 && <div className="w-6 h-6 rounded-full bg-brand-black border border-brand-dark flex items-center justify-center text-[8px] text-white">...</div>}
                     </div>
                     <div className="flex items-center gap-1 text-xs text-brand-gray">
                        <Clock size={12} />
                        <span>{project.endDate}</span>
                     </div>
                  </div>
               </div>
            </div>
          ))}

          {/* New Project Placeholder */}
          <button className="border-2 border-dashed border-white/5 hover:border-brand-bright/30 rounded-2xl p-6 flex flex-col items-center justify-center gap-3 text-brand-gray hover:text-white hover:bg-white/5 transition-all min-h-[250px]">
             <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center">
                <Plus size={24} />
             </div>
             <span className="font-bold text-sm">{t.createBtn}</span>
          </button>
       </div>
    </div>
  );
};
