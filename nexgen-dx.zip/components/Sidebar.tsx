
import React from 'react';
import { LayoutDashboard, ClipboardList, Map, Users, TestTube2, LogOut, Globe, FolderKanban } from 'lucide-react';
import { FeatureId, Language } from '../types';

interface SidebarProps {
  currentFeature: FeatureId;
  onNavigate: (feature: FeatureId) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentFeature, onNavigate, language, setLanguage }) => {
  const translations = {
    en: {
      dashboard: 'Dashboard',
      assessment: 'DX Assessment',
      roadmap: 'Smart Roadmap',
      projects: 'Project Tracking',
      experts: 'Expert Match',
      modellab: 'Model Lab',
      signOut: 'Sign Out'
    },
    vi: {
      dashboard: 'Tổng quan',
      assessment: 'Đánh giá DX',
      roadmap: 'Lộ trình số',
      projects: 'Quản lý Dự án',
      experts: 'Chuyên gia',
      modellab: 'Mô hình hóa',
      signOut: 'Đăng xuất'
    }
  };

  const t = translations[language];

  const navItems = [
    { id: FeatureId.DASHBOARD, label: t.dashboard, icon: LayoutDashboard },
    { id: FeatureId.ASSESSMENT, label: t.assessment, icon: ClipboardList },
    { id: FeatureId.ROADMAP, label: t.roadmap, icon: Map },
    { id: FeatureId.PROJECTS, label: t.projects, icon: FolderKanban },
    { id: FeatureId.EXPERTS, label: t.experts, icon: Users },
    { id: FeatureId.MODELLAB, label: t.modellab, icon: TestTube2 },
  ];

  return (
    <div className="w-64 h-screen bg-brand-dark border-r border-brand-dark flex flex-col shadow-2xl z-20">
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-8 h-8 bg-gradient-to-br from-brand-red to-brand-crimson rounded-lg flex items-center justify-center shadow-lg shadow-brand-red/20">
            <span className="font-bold text-white text-lg">N</span>
          </div>
          <h1 className="text-xl font-display font-bold tracking-tight text-white">NexGen<span className="text-brand-bright">DX</span></h1>
        </div>
        
        {/* Language Switcher */}
        <div className="flex bg-brand-black/40 p-1 rounded-lg border border-white/5">
          <button 
            onClick={() => setLanguage('en')}
            className={`flex-1 text-xs font-medium py-1.5 rounded-md transition-all ${language === 'en' ? 'bg-brand-bright text-white shadow' : 'text-brand-gray hover:text-white'}`}
          >
            English
          </button>
          <button 
            onClick={() => setLanguage('vi')}
            className={`flex-1 text-xs font-medium py-1.5 rounded-md transition-all ${language === 'vi' ? 'bg-brand-bright text-white shadow' : 'text-brand-gray hover:text-white'}`}
          >
            Tiếng Việt
          </button>
        </div>
      </div>

      <nav className="flex-1 px-4 py-2 space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentFeature === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                isActive 
                  ? 'bg-gradient-to-r from-brand-wine to-brand-dark text-white border-l-4 border-brand-bright' 
                  : 'text-brand-gray hover:bg-white/5 hover:text-white'
              }`}
            >
              <Icon size={20} className={`${isActive ? 'text-brand-bright' : 'text-brand-gray group-hover:text-white'}`} />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-white/5">
        <div className="bg-gradient-to-br from-brand-black to-brand-dark p-4 rounded-xl border border-white/5">
          <div className="flex items-center space-x-3 mb-3">
            <img src="https://picsum.photos/100/100" alt="User" className="w-10 h-10 rounded-full border-2 border-brand-red" />
            <div>
              <p className="text-sm font-semibold text-white">Alexander V.</p>
              <p className="text-xs text-brand-gray">CEO, TechCorp</p>
            </div>
          </div>
          <button className="w-full flex items-center justify-center space-x-2 text-xs font-medium text-brand-gray hover:text-brand-bright transition-colors">
            <LogOut size={14} />
            <span>{t.signOut}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
