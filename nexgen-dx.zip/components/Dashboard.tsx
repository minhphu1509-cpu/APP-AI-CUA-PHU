import React, { useMemo } from 'react';
import { 
  ResponsiveContainer, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar, 
  Tooltip, 
  Legend,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid
} from 'recharts';
import { AssessmentResult, Language } from '../types';
import { 
  Target, 
  TrendingUp, 
  Download, 
  Building, 
  Activity, 
  Zap, 
  Globe, 
  ArrowUpRight,
  Cpu,
  Share2,
  Calendar
} from 'lucide-react';

interface DashboardProps {
  data: AssessmentResult | null;
  onStartAssessment: () => void;
  language: Language;
}

// Helper to generate simulated historical data based on current score
const generateTrendData = (currentScore: number) => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  const data = [];
  let baseScore = Math.max(20, currentScore - 25);
  
  for (let i = 0; i < 5; i++) {
    data.push({
      month: months[i],
      score: Math.round(baseScore + (Math.random() * 5)),
      industry: Math.round(baseScore + 10 + (Math.random() * 5))
    });
    baseScore += 4;
  }
  // Current month matches actual score
  data.push({
    month: months[5],
    score: currentScore,
    industry: Math.round(baseScore + 10)
  });
  return data;
};

export const Dashboard: React.FC<DashboardProps> = ({ data, onStartAssessment, language }) => {
  const translations = {
    en: {
      heroTitle: "Unlock Your",
      heroTitleHighlight: "Digital Future",
      heroDesc: "NexGen DX leverages advanced AI to audit your digital DNA. Establish your baseline, identify critical gaps, and execute a data-driven transformation strategy.",
      startBtn: "Initialize Assessment",
      dashboardTitle: "Command Center",
      dashboardSubtitle: "Real-time digital maturity analytics & strategic intelligence.",
      exportBtn: "Export PDF",
      shareBtn: "Share Report",
      metrics: {
        dxIndex: "DX Index",
        marketPos: "Market Position",
        velocity: "Digital Velocity",
        actions: "Critical Actions"
      },
      charts: {
        maturityMap: "Maturity Radar",
        trendAnalysis: "Growth Trajectory (6 Mo)",
        dimensionBreakdown: "Dimension Analysis"
      },
      insightTitle: "AI Executive Summary",
      roadmapPreview: "Immediate Priorities",
      industry: "Industry",
      yourScore: "Your Score",
      leaderScore: "Industry Avg",
      dimensions: {
        data: 'Data',
        tech: 'Technology',
        process: 'Process',
        people: 'People',
        strategy: 'Strategy'
      }
    },
    vi: {
      heroTitle: "Khai Phá",
      heroTitleHighlight: "Tương Lai Số",
      heroDesc: "NexGen DX sử dụng AI tiên tiến để giải mã DNA số của doanh nghiệp. Thiết lập điểm chuẩn, xác định lỗ hổng và thực thi chiến lược chuyển đổi dựa trên dữ liệu.",
      startBtn: "Khởi tạo Đánh giá",
      dashboardTitle: "Trung Tâm Điều Hành",
      dashboardSubtitle: "Phân tích trưởng thành số & thông tin chiến lược thời gian thực.",
      exportBtn: "Xuất PDF",
      shareBtn: "Chia sẻ",
      metrics: {
        dxIndex: "Chỉ số DX",
        marketPos: "Vị thế Thị trường",
        velocity: "Tốc độ Số hóa",
        actions: "Hành động Gấp"
      },
      charts: {
        maturityMap: "Radar Trưởng Thành",
        trendAnalysis: "Quỹ Đạo Tăng Trưởng (6T)",
        dimensionBreakdown: "Phân Tích Chi Tiết"
      },
      insightTitle: "Tóm Lược Điều Hành AI",
      roadmapPreview: "Ưu Tiên Trước Mắt",
      industry: "Ngành",
      yourScore: "Điểm của bạn",
      leaderScore: "TB Ngành",
      dimensions: {
        data: 'Dữ liệu',
        tech: 'Công nghệ',
        process: 'Quy trình',
        people: 'Con người',
        strategy: 'Chiến lược'
      }
    }
  };

  const t = translations[language];

  // Memoize calculations
  const dashboardData = useMemo(() => {
    if (!data) return null;

    const overallScore = Math.round(
      (data.scores.data + data.scores.technology + data.scores.process + data.scores.people + data.scores.strategy) / 5
    );

    const trendData = generateTrendData(overallScore);
    
    // Simulate percentile based on score (mock logic)
    const percentile = Math.min(99, Math.round(overallScore * 1.1)); 
    
    // Count immediate actions
    const criticalActions = data.roadmap.filter(r => r.phase === 'Short Term').length;

    const radarData = [
      { subject: t.dimensions.data, A: data.scores.data, B: 65, fullMark: 100 },
      { subject: t.dimensions.tech, A: data.scores.technology, B: 70, fullMark: 100 },
      { subject: t.dimensions.process, A: data.scores.process, B: 60, fullMark: 100 },
      { subject: t.dimensions.people, A: data.scores.people, B: 55, fullMark: 100 },
      { subject: t.dimensions.strategy, A: data.scores.strategy, B: 75, fullMark: 100 },
    ];

    return { overallScore, trendData, percentile, criticalActions, radarData };
  }, [data, t.dimensions]);

  if (!data || !dashboardData) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 text-center bg-[url('https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center relative">
        <div className="absolute inset-0 bg-gradient-to-t from-brand-black via-brand-black/90 to-brand-wine/20 backdrop-blur-[2px]"></div>
        
        <div className="relative z-10 max-w-3xl flex flex-col items-center animate-fade-in-up">
          <div className="w-20 h-20 mb-8 rounded-2xl bg-gradient-to-br from-brand-wine to-brand-red flex items-center justify-center shadow-2xl shadow-brand-red/40 border border-white/10">
            <Cpu className="text-white w-10 h-10" />
          </div>
          
          <h2 className="text-5xl md:text-6xl font-display font-bold text-white mb-6 tracking-tight">
            {t.heroTitle} <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-bright to-brand-crimson">
              {t.heroTitleHighlight}
            </span>
          </h2>
          
          <p className="text-xl text-brand-gray mb-10 leading-relaxed max-w-2xl">
            {t.heroDesc}
          </p>
          
          <button
            onClick={onStartAssessment}
            className="group relative px-8 py-4 bg-brand-light text-brand-black rounded-full font-bold text-lg shadow-[0_0_40px_-10px_rgba(255,255,255,0.3)] hover:shadow-[0_0_60px_-15px_rgba(229,56,59,0.5)] transition-all transform hover:scale-105 overflow-hidden"
          >
            <span className="relative z-10 flex items-center gap-2">
              {t.startBtn} <ArrowUpRight size={20} />
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-brand-bright to-brand-red opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="absolute inset-0 bg-brand-light opacity-100 group-hover:opacity-0 transition-opacity duration-300"></div>
          </button>
          
          <div className="mt-12 flex items-center gap-8 text-sm text-brand-gray/60 font-mono">
            <span className="flex items-center gap-2"><Globe size={14}/> Global Standards</span>
            <span className="flex items-center gap-2"><Zap size={14}/> AI Powered</span>
            <span className="flex items-center gap-2"><Activity size={14}/> Real-time Analytics</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 h-full overflow-y-auto bg-brand-black">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
             <h2 className="text-2xl font-display font-bold text-white uppercase tracking-wider">{t.dashboardTitle}</h2>
             {data.industry && (
                <span className="bg-white/5 text-brand-bright px-3 py-0.5 rounded text-xs font-mono border border-white/10 flex items-center gap-1">
                  <Building size={10} /> {data.industry}
                </span>
             )}
          </div>
          <p className="text-brand-gray text-sm font-light">{t.dashboardSubtitle}</p>
        </div>
        <div className="flex items-center space-x-3">
          <button className="flex items-center space-x-2 bg-brand-dark/50 border border-white/10 hover:bg-white/5 text-brand-gray hover:text-white px-4 py-2 rounded-lg transition-colors text-xs font-medium">
            <Share2 size={14} />
            <span className="hidden sm:inline">{t.shareBtn}</span>
          </button>
          <button className="flex items-center space-x-2 bg-brand-bright hover:bg-brand-red text-white px-4 py-2 rounded-lg transition-all shadow-lg shadow-brand-red/20 text-xs font-bold">
            <Download size={14} />
            <span>{t.exportBtn}</span>
          </button>
        </div>
      </div>

      {/* KPI BENTO GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* Metric 1: DX Index */}
        <div className="bg-gradient-to-br from-brand-dark to-brand-black border border-white/5 p-5 rounded-xl shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-3 opacity-20 group-hover:opacity-40 transition-opacity text-brand-bright">
            <Activity size={40} />
          </div>
          <p className="text-brand-gray text-xs font-mono uppercase tracking-widest mb-2">{t.metrics.dxIndex}</p>
          <div className="flex items-end gap-2">
            <span className="text-4xl font-display font-bold text-white">{dashboardData.overallScore}</span>
            <span className="text-sm text-brand-gray/60 mb-1">/100</span>
          </div>
          <div className="mt-3 w-full bg-white/5 h-1 rounded-full overflow-hidden">
            <div className="h-full bg-brand-bright" style={{ width: `${dashboardData.overallScore}%` }}></div>
          </div>
        </div>

        {/* Metric 2: Market Position */}
        <div className="bg-brand-dark border border-white/5 p-5 rounded-xl shadow-lg group hover:border-brand-gray/20 transition-colors">
          <div className="flex justify-between items-start mb-2">
            <p className="text-brand-gray text-xs font-mono uppercase tracking-widest">{t.metrics.marketPos}</p>
            <Globe size={16} className="text-brand-gray group-hover:text-white transition-colors" />
          </div>
          <div className="flex items-end gap-2">
            <span className="text-4xl font-display font-bold text-white">Top {100 - dashboardData.percentile}%</span>
          </div>
          <p className="text-xs text-green-400 mt-2 flex items-center gap-1">
            <ArrowUpRight size={12} /> Better than {dashboardData.percentile}% of peers
          </p>
        </div>

        {/* Metric 3: Digital Velocity */}
        <div className="bg-brand-dark border border-white/5 p-5 rounded-xl shadow-lg group hover:border-brand-gray/20 transition-colors">
          <div className="flex justify-between items-start mb-2">
            <p className="text-brand-gray text-xs font-mono uppercase tracking-widest">{t.metrics.velocity}</p>
            <Zap size={16} className="text-brand-gray group-hover:text-white transition-colors" />
          </div>
          <div className="flex items-end gap-2">
            <span className="text-4xl font-display font-bold text-white">+12.5%</span>
          </div>
          <p className="text-xs text-brand-gray mt-2">MoM Growth Rate</p>
        </div>

         {/* Metric 4: Actions */}
         <div className="bg-brand-dark border border-white/5 p-5 rounded-xl shadow-lg group hover:border-brand-gray/20 transition-colors">
          <div className="flex justify-between items-start mb-2">
            <p className="text-brand-gray text-xs font-mono uppercase tracking-widest">{t.metrics.actions}</p>
            <Target size={16} className="text-brand-gray group-hover:text-white transition-colors" />
          </div>
          <div className="flex items-end gap-2">
            <span className="text-4xl font-display font-bold text-brand-bright">{dashboardData.criticalActions}</span>
            <span className="text-sm text-brand-gray mb-1">items</span>
          </div>
          <p className="text-xs text-brand-gray mt-2">Requires immediate attention</p>
        </div>
      </div>

      {/* CHARTS ROW */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Radar Chart */}
        <div className="bg-brand-dark border border-white/5 p-4 rounded-xl shadow-lg flex flex-col h-[400px]">
           <div className="flex justify-between items-center mb-2 px-2">
             <h3 className="text-white font-bold text-sm flex items-center gap-2">
               <Cpu size={14} className="text-brand-bright"/> {t.charts.maturityMap}
             </h3>
           </div>
           <div className="flex-1 w-full min-h-0 relative">
             {/* Decorative Grid Background */}
             <div className="absolute inset-0 bg-[radial-gradient(#ffffff05_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none"></div>
             
             <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="70%" data={dashboardData.radarData}>
                <PolarGrid stroke="#333" strokeDasharray="3 3" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#9CA3AF', fontSize: 10, fontWeight: 600 }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                <Radar
                  name={t.leaderScore}
                  dataKey="B"
                  stroke="#525252"
                  strokeWidth={1}
                  fill="#525252"
                  fillOpacity={0.1}
                />
                <Radar
                  name={t.yourScore}
                  dataKey="A"
                  stroke="#e5383b"
                  strokeWidth={2}
                  fill="#ba181b"
                  fillOpacity={0.4}
                />
                <Legend iconType="rect" wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0b090a', borderColor: '#333', color: '#fff', borderRadius: '8px', fontSize: '12px' }}
                  itemStyle={{ color: '#fff' }}
                />
              </RadarChart>
            </ResponsiveContainer>
           </div>
        </div>

        {/* Trend Area Chart */}
        <div className="bg-brand-dark border border-white/5 p-4 rounded-xl shadow-lg flex flex-col h-[400px]">
           <div className="flex justify-between items-center mb-2 px-2">
             <h3 className="text-white font-bold text-sm flex items-center gap-2">
               <TrendingUp size={14} className="text-brand-bright"/> {t.charts.trendAnalysis}
             </h3>
           </div>
           <div className="flex-1 w-full min-h-0">
             <ResponsiveContainer width="100%" height="100%">
               <AreaChart data={dashboardData.trendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                 <defs>
                   <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                     <stop offset="5%" stopColor="#e5383b" stopOpacity={0.3}/>
                     <stop offset="95%" stopColor="#e5383b" stopOpacity={0}/>
                   </linearGradient>
                 </defs>
                 <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                 <XAxis dataKey="month" stroke="#666" fontSize={10} tickLine={false} axisLine={false} />
                 <YAxis stroke="#666" fontSize={10} tickLine={false} axisLine={false} />
                 <Tooltip 
                    contentStyle={{ backgroundColor: '#0b090a', borderColor: '#333', color: '#fff', borderRadius: '8px', fontSize: '12px' }}
                    itemStyle={{ color: '#fff' }}
                 />
                 <Area type="monotone" dataKey="score" stroke="#e5383b" fillOpacity={1} fill="url(#colorScore)" strokeWidth={2} />
                 <Area type="monotone" dataKey="industry" stroke="#525252" fillOpacity={0} strokeDasharray="4 4" strokeWidth={1} />
               </AreaChart>
             </ResponsiveContainer>
           </div>
        </div>

        {/* Dimension Breakdown List */}
        <div className="bg-brand-dark border border-white/5 p-6 rounded-xl shadow-lg overflow-y-auto h-[400px]">
           <h3 className="text-white font-bold text-sm mb-6 flex items-center gap-2">
             <Activity size={14} className="text-brand-bright"/> {t.charts.dimensionBreakdown}
           </h3>
           <div className="space-y-6">
             {dashboardData.radarData.map((item, idx) => (
               <div key={idx}>
                 <div className="flex justify-between items-center mb-2">
                   <span className="text-brand-gray text-xs font-medium">{item.subject}</span>
                   <span className="text-white text-xs font-mono">{item.A}/100</span>
                 </div>
                 <div className="h-2 w-full bg-brand-black rounded-full overflow-hidden border border-white/5">
                   <div 
                     className={`h-full rounded-full ${
                       item.A >= 80 ? 'bg-green-500' : item.A >= 50 ? 'bg-yellow-500' : 'bg-brand-red'
                     }`}
                     style={{ width: `${item.A}%` }}
                   ></div>
                 </div>
               </div>
             ))}
           </div>
        </div>
      </div>

      {/* BOTTOM SECTION: Insights & Roadmap */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* AI Insight Terminal */}
        <div className="col-span-1 lg:col-span-2 bg-gradient-to-r from-brand-dark to-brand-black border border-white/10 p-6 rounded-xl relative overflow-hidden">
          <div className="flex items-center gap-2 mb-4">
             <div className="w-2 h-2 bg-brand-bright rounded-full animate-pulse"></div>
             <h3 className="text-white font-mono text-sm uppercase tracking-widest">{t.insightTitle}</h3>
          </div>
          <div className="font-mono text-sm text-brand-light leading-relaxed opacity-90 border-l-2 border-brand-red/50 pl-4 py-1">
            {data.summary}
          </div>
          <div className="mt-4 flex gap-2">
             <span className="text-[10px] bg-brand-bright/10 text-brand-bright px-2 py-1 rounded border border-brand-bright/20">Strategy Generated</span>
             <span className="text-[10px] bg-brand-gray/10 text-brand-gray px-2 py-1 rounded border border-white/5">Confidence: 98%</span>
          </div>
        </div>

        {/* Quick Roadmap Priorities */}
        <div className="bg-brand-dark border border-white/5 p-6 rounded-xl">
           <div className="flex justify-between items-center mb-4">
             <h3 className="text-white font-bold text-sm flex items-center gap-2">
                <Calendar size={14} className="text-brand-bright"/> {t.roadmapPreview}
             </h3>
           </div>
           <div className="space-y-3">
             {data.roadmap.filter(i => i.phase === 'Short Term').slice(0, 3).map((item, idx) => (
                <div key={idx} className="p-3 bg-white/5 rounded-lg border border-white/5 flex gap-3 items-start group hover:bg-white/10 transition-colors">
                  <div className="mt-1 w-1.5 h-1.5 rounded-full bg-brand-bright shrink-0"></div>
                  <div>
                    <p className="text-xs text-white font-medium mb-1 line-clamp-2">{item.title}</p>
                    <p className="text-[10px] text-brand-gray font-mono">KPI: {item.kpi}</p>
                  </div>
                </div>
             ))}
           </div>
        </div>

      </div>
    </div>
  );
};