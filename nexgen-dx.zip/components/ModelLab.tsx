
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Send, TestTube2, Bot, User, Sparkles, Zap, LayoutGrid, TrendingUp, ShieldAlert, Sliders, ChevronRight, RotateCcw, Download } from 'lucide-react';
import { chatWithModelLab, generateBusinessModel } from '../services/geminiService';
import { ChatMessage, Language, SimulationResult, FinancialParams, BusinessModelCanvas } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';

interface ModelLabProps {
  language: Language;
}

// Helper to generate financial projection data based on params
const calculateProjections = (params: FinancialParams) => {
  const data = [];
  let currentUsers = params.initialUsers;
  let totalRevenue = 0;

  for (let month = 1; month <= 36; month++) {
    // Basic calculation logic
    const newUsers = currentUsers * (params.monthlyGrowth / 100);
    const churnedUsers = currentUsers * (params.churnRate / 100);
    currentUsers = currentUsers + newUsers - churnedUsers;
    
    // Revenue
    const monthlyRevenue = currentUsers * params.price;
    totalRevenue += monthlyRevenue;

    // Costs (Simplified)
    const marketingCost = newUsers * params.costPerAcquisition;
    const operationalCost = monthlyRevenue * 0.3; // Assume 30% op cost
    const profit = monthlyRevenue - marketingCost - operationalCost;

    data.push({
      month: `M${month}`,
      revenue: Math.round(monthlyRevenue),
      profit: Math.round(profit),
      users: Math.round(currentUsers)
    });
  }
  return data;
};

export const ModelLab: React.FC<ModelLabProps> = ({ language }) => {
  const [activeTab, setActiveTab] = useState<'canvas' | 'financials' | 'swot'>('canvas');
  const [simulation, setSimulation] = useState<SimulationResult | null>(null);
  const [params, setParams] = useState<FinancialParams | null>(null); // Local mutable params
  
  // Chat State
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  // Input Idea State (Initial State)
  const [ideaInput, setIdeaInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const t = {
    en: {
      inputPlaceholder: "Describe your business idea (e.g., 'Uber for dog walkers' or 'SaaS for dental clinics')...",
      generateBtn: "Generate Model",
      generating: "Architecting Business Model...",
      tabs: { canvas: 'Canvas', financials: 'Projections', swot: 'SWOT Analysis' },
      chatTitle: "AI Consultant",
      chatPlaceholder: "Ask about this model...",
      paramsTitle: "Simulation Parameters",
      canvas: {
        kp: 'Key Partners', ka: 'Key Activities', kr: 'Key Resources',
        vp: 'Value Propositions', cr: 'Relationships', ch: 'Channels',
        cs: 'Customer Segments', cst: 'Cost Structure', rs: 'Revenue Streams'
      },
      financials: {
        price: "Monthly Price", growth: "MoM Growth (%)", churn: "Churn Rate (%)", 
        cac: "CAC ($)", initial: "Initial Users"
      },
      welcome: "Welcome to Model Lab 2.0. I can simulate any business model. Start by describing your idea.",
      chartRev: "Revenue", chartProf: "Profit",
      export: "Export Report"
    },
    vi: {
      inputPlaceholder: "Mô tả ý tưởng kinh doanh (VD: 'Uber cho người dắt chó' hoặc 'Phần mềm quản lý nha khoa')...",
      generateBtn: "Tạo Mô Hình",
      generating: "Đang kiến tạo mô hình...",
      tabs: { canvas: 'Canvas', financials: 'Dự báo', swot: 'Phân tích SWOT' },
      chatTitle: "Trợ lý AI",
      chatPlaceholder: "Hỏi về mô hình này...",
      paramsTitle: "Tham số Mô phỏng",
      canvas: {
        kp: 'Đối tác Chính', ka: 'Hoạt động Chính', kr: 'Nguồn lực Chính',
        vp: 'Giá trị Cốt lõi', cr: 'Quan hệ KH', ch: 'Kênh',
        cs: 'Phân khúc KH', cst: 'Cấu trúc CP', rs: 'Dòng Doanh thu'
      },
      financials: {
        price: "Giá/Tháng", growth: "Tăng trưởng (%)", churn: "Rời bỏ (%)", 
        cac: "Chi phí QC ($)", initial: "User Ban đầu"
      },
      welcome: "Chào mừng đến Model Lab 2.0. Tôi có thể mô phỏng bất kỳ mô hình nào. Hãy bắt đầu bằng cách mô tả ý tưởng.",
      chartRev: "Doanh thu", chartProf: "Lợi nhuận",
      export: "Xuất Báo cáo"
    }
  }[language];

  // Initialize Chat
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{
        id: 'init', role: 'model', text: t.welcome, timestamp: new Date()
      }]);
    }
  }, [language]);

  // Scroll chat
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages]);

  // Handle Generation
  const handleGenerate = async () => {
    if (!ideaInput.trim()) return;
    setIsGenerating(true);
    try {
      const result = await generateBusinessModel(ideaInput, language);
      setSimulation(result);
      setParams(result.params);
      
      // Add system message to chat
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'model',
        text: language === 'vi' 
          ? `Tôi đã tạo mô hình cho "${result.name}". Bạn có thể xem Canvas và điều chỉnh các thông số tài chính bên dưới.`
          : `I've generated the model for "${result.name}". You can review the Canvas and tweak financial parameters below.`,
        timestamp: new Date()
      }]);
    } catch (error) {
      console.error(error);
      alert("Failed to generate model. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  // Handle Chat
  const handleChatSend = async () => {
    if (!chatInput.trim()) return;
    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', text: chatInput, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setIsTyping(true);

    try {
      // Provide context of current simulation to the chat
      const context = simulation 
        ? `Current Model Context: ${JSON.stringify(simulation.canvas)}. Current Params: ${JSON.stringify(params)}.` 
        : "";
      
      const history = messages.map(m => ({ role: m.role, parts: [{ text: m.text }] }));
      // Inject context into history essentially (or just append to prompt)
      const response = await chatWithModelLab(history, context + "\nUser Question: " + userMsg.text, language);
      
      setMessages(prev => [...prev, { id: (Date.now()+1).toString(), role: 'model', text: response, timestamp: new Date() }]);
    } catch (e) {
      console.error(e);
    } finally {
      setIsTyping(false);
    }
  };

  // Financial Data
  const financialData = useMemo(() => {
    if (!params) return [];
    return calculateProjections(params);
  }, [params]);

  // Render Canvas Card
  const CanvasCard = ({ title, items, color, className }: { title: string, items: string[], color: string, className?: string }) => (
    <div className={`bg-brand-dark/40 border border-white/5 p-3 rounded-lg flex flex-col h-full overflow-hidden ${className}`}>
      <h4 className={`text-[10px] font-bold uppercase tracking-wider mb-2 ${color}`}>{title}</h4>
      <ul className="space-y-1 overflow-y-auto flex-1 custom-scrollbar">
        {items.map((item, i) => (
          <li key={i} className="text-xs text-brand-gray leading-snug flex gap-1.5">
            <span className={`mt-1 w-1 h-1 rounded-full shrink-0 ${color.replace('text-', 'bg-')}`}></span>
            {item}
          </li>
        ))}
      </ul>
    </div>
  );

  if (!simulation || !params) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 bg-brand-black relative overflow-hidden">
        {/* Abstract BG */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-brand-wine/20 via-brand-black to-brand-black pointer-events-none"></div>
        
        <div className="relative z-10 w-full max-w-2xl text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-brand-red to-brand-dark rounded-2xl mx-auto mb-8 flex items-center justify-center shadow-2xl shadow-brand-red/20 border border-white/10">
            <TestTube2 className="text-white w-10 h-10" />
          </div>
          <h2 className="text-4xl font-display font-bold text-white mb-4">Model Lab <span className="text-brand-bright">2.0</span></h2>
          <p className="text-brand-gray mb-10 text-lg">
             {language === 'vi' 
               ? "Công cụ mô phỏng và kiến tạo mô hình kinh doanh toàn diện." 
               : "Comprehensive business model generation and simulation engine."}
          </p>

          <div className="bg-brand-dark border border-white/10 rounded-2xl p-2 flex shadow-xl">
             <input 
               type="text" 
               value={ideaInput}
               onChange={(e) => setIdeaInput(e.target.value)}
               placeholder={t.inputPlaceholder}
               onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
               className="flex-1 bg-transparent px-4 py-3 text-white placeholder-brand-gray/50 focus:outline-none"
             />
             <button 
               onClick={handleGenerate}
               disabled={isGenerating || !ideaInput.trim()}
               className="bg-brand-bright text-white px-6 py-3 rounded-xl font-bold hover:bg-brand-red transition-all disabled:opacity-50 flex items-center gap-2 shrink-0"
             >
               {isGenerating ? <Sparkles size={18} className="animate-spin" /> : <Zap size={18} />}
               <span className="hidden sm:inline">{t.generateBtn}</span>
             </button>
          </div>
          
          {isGenerating && (
            <div className="mt-8 flex flex-col items-center gap-3 animate-fade-in">
               <div className="flex gap-1">
                 <div className="w-2 h-2 bg-brand-bright rounded-full animate-bounce"></div>
                 <div className="w-2 h-2 bg-brand-bright rounded-full animate-bounce delay-75"></div>
                 <div className="w-2 h-2 bg-brand-bright rounded-full animate-bounce delay-150"></div>
               </div>
               <p className="text-brand-gray text-sm font-mono">{t.generating}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex bg-brand-black overflow-hidden">
      
      {/* LEFT: Dashboard Area (70%) */}
      <div className="flex-1 flex flex-col h-full overflow-hidden border-r border-white/5 relative">
        {/* Header */}
        <div className="p-4 border-b border-white/5 bg-brand-dark/50 flex justify-between items-center backdrop-blur-md z-20">
           <div>
              <h2 className="text-white font-bold text-lg flex items-center gap-2">
                 {simulation.name}
                 <span className="text-[10px] bg-brand-bright/20 text-brand-bright px-2 py-0.5 rounded border border-brand-bright/30 uppercase">Draft</span>
              </h2>
              <p className="text-brand-gray text-xs truncate max-w-md">{simulation.description}</p>
           </div>
           
           <div className="flex bg-brand-black/50 p-1 rounded-lg border border-white/5">
              {[
                { id: 'canvas', icon: LayoutGrid, label: t.tabs.canvas },
                { id: 'financials', icon: TrendingUp, label: t.tabs.financials },
                { id: 'swot', icon: ShieldAlert, label: t.tabs.swot }
              ].map(tab => (
                 <button 
                   key={tab.id}
                   onClick={() => setActiveTab(tab.id as any)}
                   className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                      activeTab === tab.id ? 'bg-brand-bright text-white shadow' : 'text-brand-gray hover:text-white'
                   }`}
                 >
                    <tab.icon size={14} /> {tab.label}
                 </button>
              ))}
           </div>
           
           <button className="p-2 text-brand-gray hover:text-white border border-white/5 rounded-lg hover:bg-white/5 transition-colors">
              <Download size={18} />
           </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 bg-brand-black custom-scrollbar">
           
           {/* VIEW: CANVAS */}
           {activeTab === 'canvas' && (
             <div className="grid grid-cols-5 grid-rows-3 gap-3 h-[700px] min-w-[800px]">
                {/* Row 1: The big blocks */}
                <div className="row-span-3 col-span-1 flex flex-col gap-3">
                   <CanvasCard title={t.canvas.kp} items={simulation.canvas.keyPartners} color="text-blue-400" className="flex-1" />
                </div>
                
                <div className="row-span-3 col-span-1 flex flex-col gap-3">
                   <CanvasCard title={t.canvas.ka} items={simulation.canvas.keyActivities} color="text-green-400" className="h-1/2" />
                   <CanvasCard title={t.canvas.kr} items={simulation.canvas.keyResources} color="text-emerald-400" className="h-1/2" />
                </div>

                <div className="row-span-3 col-span-1">
                   <CanvasCard title={t.canvas.vp} items={simulation.canvas.valuePropositions} color="text-brand-bright" className="h-full border-brand-bright/30 bg-brand-bright/5" />
                </div>

                <div className="row-span-3 col-span-1 flex flex-col gap-3">
                   <CanvasCard title={t.canvas.cr} items={simulation.canvas.customerRelationships} color="text-purple-400" className="h-1/2" />
                   <CanvasCard title={t.canvas.ch} items={simulation.canvas.channels} color="text-indigo-400" className="h-1/2" />
                </div>

                <div className="row-span-3 col-span-1">
                   <CanvasCard title={t.canvas.cs} items={simulation.canvas.customerSegments} color="text-orange-400" className="h-full" />
                </div>

                {/* Bottom Row: Cost & Revenue (Overlaying standard grid for visual effect, or separate) */}
             </div>
           )}
           
           {/* Separate Cost/Revenue for Canvas Bottom */}
           {activeTab === 'canvas' && (
             <div className="grid grid-cols-2 gap-3 mt-3">
                <CanvasCard title={t.canvas.cst} items={simulation.canvas.costStructure} color="text-red-400" className="min-h-[150px]" />
                <CanvasCard title={t.canvas.rs} items={simulation.canvas.revenueStreams} color="text-green-500" className="min-h-[150px]" />
             </div>
           )}

           {/* VIEW: FINANCIALS */}
           {activeTab === 'financials' && (
             <div className="flex flex-col h-full space-y-6">
                {/* Chart */}
                <div className="flex-1 bg-brand-dark/30 border border-white/5 rounded-xl p-4 min-h-[400px]">
                   <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={financialData}>
                         <defs>
                            <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                               <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                               <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorProf" x1="0" y1="0" x2="0" y2="1">
                               <stop offset="5%" stopColor="#e5383b" stopOpacity={0.3}/>
                               <stop offset="95%" stopColor="#e5383b" stopOpacity={0}/>
                            </linearGradient>
                         </defs>
                         <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                         <XAxis dataKey="month" stroke="#666" fontSize={10} tickLine={false} axisLine={false} />
                         <YAxis stroke="#666" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value/1000}k`} />
                         <Tooltip 
                            contentStyle={{ backgroundColor: '#0b090a', borderColor: '#333', borderRadius: '8px' }}
                            itemStyle={{ fontSize: '12px' }}
                         />
                         <Legend />
                         <Area type="monotone" dataKey="revenue" name={t.chartRev} stroke="#10b981" fillOpacity={1} fill="url(#colorRev)" />
                         <Area type="monotone" dataKey="profit" name={t.chartProf} stroke="#e5383b" fillOpacity={1} fill="url(#colorProf)" />
                      </AreaChart>
                   </ResponsiveContainer>
                </div>
                
                {/* Controls */}
                <div className="bg-brand-dark border border-white/10 rounded-xl p-6">
                   <div className="flex items-center gap-2 mb-6">
                      <Sliders size={18} className="text-brand-bright" />
                      <h3 className="text-white font-bold">{t.paramsTitle}</h3>
                   </div>
                   
                   <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-6">
                      {/* Price Control */}
                      <div className="space-y-2">
                         <div className="flex justify-between text-xs text-brand-gray">
                            <span>{t.financials.price}</span>
                            <span className="text-white font-mono">${params.price}</span>
                         </div>
                         <input 
                            type="range" min="1" max="500" value={params.price}
                            onChange={(e) => setParams({...params, price: parseInt(e.target.value)})}
                            className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-brand-bright"
                         />
                      </div>

                      {/* Growth Control */}
                      <div className="space-y-2">
                         <div className="flex justify-between text-xs text-brand-gray">
                            <span>{t.financials.growth}</span>
                            <span className="text-white font-mono">{params.monthlyGrowth}%</span>
                         </div>
                         <input 
                            type="range" min="1" max="50" step="0.5" value={params.monthlyGrowth}
                            onChange={(e) => setParams({...params, monthlyGrowth: parseFloat(e.target.value)})}
                            className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-brand-bright"
                         />
                      </div>

                      {/* Churn Control */}
                      <div className="space-y-2">
                         <div className="flex justify-between text-xs text-brand-gray">
                            <span>{t.financials.churn}</span>
                            <span className="text-white font-mono">{params.churnRate}%</span>
                         </div>
                         <input 
                            type="range" min="0" max="20" step="0.1" value={params.churnRate}
                            onChange={(e) => setParams({...params, churnRate: parseFloat(e.target.value)})}
                            className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-brand-bright"
                         />
                      </div>
                      
                      {/* CAC Control */}
                      <div className="space-y-2">
                         <div className="flex justify-between text-xs text-brand-gray">
                            <span>{t.financials.cac}</span>
                            <span className="text-white font-mono">${params.costPerAcquisition}</span>
                         </div>
                         <input 
                            type="range" min="0" max="200" value={params.costPerAcquisition}
                            onChange={(e) => setParams({...params, costPerAcquisition: parseInt(e.target.value)})}
                            className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-brand-bright"
                         />
                      </div>

                      {/* Initial Users Control */}
                      <div className="space-y-2">
                         <div className="flex justify-between text-xs text-brand-gray">
                            <span>{t.financials.initial}</span>
                            <span className="text-white font-mono">{params.initialUsers}</span>
                         </div>
                         <input 
                            type="range" min="10" max="1000" step="10" value={params.initialUsers}
                            onChange={(e) => setParams({...params, initialUsers: parseInt(e.target.value)})}
                            className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-brand-bright"
                         />
                      </div>
                   </div>
                </div>
             </div>
           )}

           {/* VIEW: SWOT */}
           {activeTab === 'swot' && (
             <div className="grid grid-cols-2 gap-4 h-full">
                <CanvasCard title="Strengths" items={simulation.swot.strengths} color="text-green-400" className="bg-green-500/5 border-green-500/20" />
                <CanvasCard title="Weaknesses" items={simulation.swot.weaknesses} color="text-orange-400" className="bg-orange-500/5 border-orange-500/20" />
                <CanvasCard title="Opportunities" items={simulation.swot.opportunities} color="text-blue-400" className="bg-blue-500/5 border-blue-500/20" />
                <CanvasCard title="Threats" items={simulation.swot.threats} color="text-red-400" className="bg-red-500/5 border-red-500/20" />
             </div>
           )}

        </div>
      </div>

      {/* RIGHT: Chat Assistant (30%) */}
      <div className="w-[350px] bg-brand-dark/20 flex flex-col border-l border-white/5">
         <div className="p-4 border-b border-white/5 bg-brand-black/50">
            <h3 className="text-white font-bold text-sm flex items-center gap-2">
               <Bot size={16} className="text-brand-bright" /> {t.chatTitle}
            </h3>
         </div>
         
         <div className="flex-1 overflow-y-auto p-4 space-y-4" ref={chatScrollRef}>
            {messages.map(msg => (
               <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[90%] p-3 rounded-xl text-xs leading-relaxed ${
                     msg.role === 'user' 
                       ? 'bg-brand-bright text-white rounded-br-none' 
                       : 'bg-brand-dark border border-white/10 text-brand-light rounded-bl-none'
                  }`}>
                     {msg.text}
                  </div>
               </div>
            ))}
            {isTyping && (
               <div className="flex gap-1 p-2">
                  <div className="w-1.5 h-1.5 bg-brand-gray/50 rounded-full animate-bounce"></div>
                  <div className="w-1.5 h-1.5 bg-brand-gray/50 rounded-full animate-bounce delay-75"></div>
                  <div className="w-1.5 h-1.5 bg-brand-gray/50 rounded-full animate-bounce delay-150"></div>
               </div>
            )}
         </div>

         <div className="p-4 border-t border-white/5 bg-brand-black">
            <div className="relative">
               <input 
                 type="text" 
                 value={chatInput}
                 onChange={(e) => setChatInput(e.target.value)}
                 onKeyDown={(e) => e.key === 'Enter' && handleChatSend()}
                 placeholder={t.chatPlaceholder}
                 className="w-full bg-brand-dark border border-white/10 rounded-lg py-3 pl-3 pr-10 text-white text-xs placeholder-brand-gray/50 focus:outline-none focus:border-brand-bright/50"
               />
               <button 
                 onClick={handleChatSend}
                 disabled={!chatInput.trim() || isTyping}
                 className="absolute right-2 top-2 p-1 text-brand-bright hover:text-white transition-colors"
               >
                  <Send size={16} />
               </button>
            </div>
            
            <button 
              onClick={() => { setSimulation(null); setMessages([]); setIdeaInput(''); }}
              className="mt-3 flex items-center justify-center gap-2 w-full py-2 border border-white/5 rounded-lg text-[10px] text-brand-gray hover:text-white hover:bg-white/5 transition-colors"
            >
               <RotateCcw size={12} /> New Model
            </button>
         </div>
      </div>
    </div>
  );
};