
import { GoogleGenAI, Type } from "@google/genai";
import { AssessmentResult, Language, SimulationResult } from "../types";

// Initialize the API client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface AssessmentContext {
  industry: string;
  companySize: string;
  role: string;
  answers: Record<string, string>; // ID -> Option Selected
  focusAreas: Record<string, string[]>; // ID -> Array of selected tags
}

export const analyzeAssessment = async (
  context: AssessmentContext,
  language: Language
): Promise<AssessmentResult> => {
  const modelId = "gemini-2.5-flash"; 

  const langInstruction = language === 'vi' 
    ? "OUTPUT RULES: Provide 'summary', 'title', 'description', and 'kpi' fields in Vietnamese. Keep the 'phase' values exactly as 'Short Term', 'Medium Term', 'Long Term'."
    : "OUTPUT RULES: Provide the response in English.";

  const prompt = `
    Act as a World-Class Digital Transformation (DX) Strategist.
    
    CLIENT PROFILE:
    - Industry: ${context.industry}
    - Company Size: ${context.companySize}
    - Role: ${context.role}
    
    ASSESSMENT DATA:
    - Maturity Inputs: ${JSON.stringify(context.answers)}
    - Critical Pain Points: ${JSON.stringify(context.focusAreas)}

    TASK:
    1. SCORING: Calculate maturity scores (0-100) for 5 axes: Data, Technology, Process, People, Strategy based on the inputs.
    
    2. STRATEGIC ROADMAP: Generate a detailed 3-phase transformation plan.
       - SHORT TERM (0-6 Months): "Fix & Foundation". Address specific pain points listed above. prioritize quick wins.
       - MEDIUM TERM (6-18 Months): "Integrate & Scale". Connect systems, automate processes, upskill workforce.
       - LONG TERM (18-36 Months): "Innovate & Lead". AI-driven business models, ecosystem dominance.
       
    3. MANDATORY KPIs: Each roadmap item MUST have a specific, quantifiable Key Performance Indicator (e.g., "Reduce OpEx by 15%", "Achieve 99.9% Data Accuracy").
    
    4. EXECUTIVE SUMMARY: A concise, high-impact strategic overview for the ${context.role}.

    ${langInstruction}
  `;

  const response = await ai.models.generateContent({
    model: modelId,
    contents: prompt,
    config: {
      thinkingConfig: { thinkingBudget: 2048 },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          scores: {
            type: Type.OBJECT,
            properties: {
              data: { type: Type.NUMBER },
              technology: { type: Type.NUMBER },
              process: { type: Type.NUMBER },
              people: { type: Type.NUMBER },
              strategy: { type: Type.NUMBER },
            },
            required: ["data", "technology", "process", "people", "strategy"]
          },
          summary: { type: Type.STRING },
          roadmap: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                phase: { type: Type.STRING, enum: ["Short Term", "Medium Term", "Long Term"] },
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                kpi: { type: Type.STRING }
              },
              required: ["phase", "title", "description", "kpi"]
            }
          }
        },
        required: ["scores", "summary", "roadmap"]
      }
    }
  });

  if (response.text) {
    const result = JSON.parse(response.text) as AssessmentResult;
    result.industry = context.industry;
    return result;
  }
  
  throw new Error("Failed to generate assessment analysis");
};

export const chatWithModelLab = async (
  history: { role: string; parts: { text: string }[] }[],
  message: string,
  language: Language
): Promise<string> => {
  const modelId = "gemini-2.5-flash";

  const systemInstruction = language === 'vi'
    ? "Bạn là một Kiến trúc sư Mô hình Kinh doanh chuyên gia trong 'Phòng thí nghiệm Mô hình'. Bạn giúp người dùng mô phỏng các mô hình kinh doanh mới (Đăng ký, Hệ sinh thái, Nền tảng, v.v.). Đưa ra phân tích phản biện, các dòng doanh thu tiềm năng và rủi ro. Giữ câu trả lời chuyên nghiệp nhưng đầy tầm nhìn. Trả lời bằng tiếng Việt."
    : "You are an expert Business Model Architect in the 'Model Lab'. You help users simulate new business models (Subscription, Ecosystem, Platform, etc.). Provide critical analysis, potential revenue streams, and risks. Keep answers professional yet visionary.";

  const chat = ai.chats.create({
    model: modelId,
    history: history,
    config: {
      systemInstruction: systemInstruction,
    }
  });

  const response = await chat.sendMessage({ message });
  return response.text || "I apologize, I could not process that request.";
};

export const generateBusinessModel = async (
  inputIdea: string,
  language: Language
): Promise<SimulationResult> => {
  const modelId = "gemini-2.5-flash";
  
  const prompt = language === 'vi'
    ? `Tạo một mô hình kinh doanh chi tiết cho ý tưởng: "${inputIdea}". 
       Cung cấp Business Model Canvas, phân tích SWOT, và các tham số tài chính ước tính cho 1 startup ở giai đoạn đầu.
       Trả về JSON.`
    : `Generate a detailed business model for the idea: "${inputIdea}".
       Provide a Business Model Canvas, SWOT analysis, and estimated financial parameters for an early-stage startup.
       Return JSON.`;

  const response = await ai.models.generateContent({
    model: modelId,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "A catchy name for this project/business" },
          description: { type: Type.STRING, description: "Short elevator pitch" },
          canvas: {
            type: Type.OBJECT,
            properties: {
              keyPartners: { type: Type.ARRAY, items: { type: Type.STRING } },
              keyActivities: { type: Type.ARRAY, items: { type: Type.STRING } },
              keyResources: { type: Type.ARRAY, items: { type: Type.STRING } },
              valuePropositions: { type: Type.ARRAY, items: { type: Type.STRING } },
              customerRelationships: { type: Type.ARRAY, items: { type: Type.STRING } },
              channels: { type: Type.ARRAY, items: { type: Type.STRING } },
              customerSegments: { type: Type.ARRAY, items: { type: Type.STRING } },
              costStructure: { type: Type.ARRAY, items: { type: Type.STRING } },
              revenueStreams: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["keyPartners", "keyActivities", "keyResources", "valuePropositions", "customerRelationships", "channels", "customerSegments", "costStructure", "revenueStreams"]
          },
          swot: {
            type: Type.OBJECT,
            properties: {
              strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
              weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
              opportunities: { type: Type.ARRAY, items: { type: Type.STRING } },
              threats: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["strengths", "weaknesses", "opportunities", "threats"]
          },
          params: {
            type: Type.OBJECT,
            properties: {
              initialUsers: { type: Type.NUMBER, description: "Estimated starting users (10-1000)" },
              monthlyGrowth: { type: Type.NUMBER, description: "Monthly growth rate in % (e.g. 5-20)" },
              price: { type: Type.NUMBER, description: "Average revenue per user per month" },
              churnRate: { type: Type.NUMBER, description: "Monthly churn in % (e.g. 2-10)" },
              costPerAcquisition: { type: Type.NUMBER, description: "Cost to acquire a user" },
            },
            required: ["initialUsers", "monthlyGrowth", "price", "churnRate", "costPerAcquisition"]
          }
        },
        required: ["name", "description", "canvas", "swot", "params"]
      }
    }
  });

  if (response.text) {
    return JSON.parse(response.text) as SimulationResult;
  }
  throw new Error("Failed to generate business model");
};

export const generateActionPlan = async (
  itemTitle: string,
  industry: string,
  language: Language
): Promise<string[]> => {
  const modelId = "gemini-2.5-flash";
  const prompt = language === 'vi'
    ? `Đối với ngành ${industry}, hãy liệt kê 3-5 bước hành động cụ thể, ngắn gọn để thực hiện sáng kiến chuyển đổi số sau: "${itemTitle}". Trả về kết quả dưới dạng mảng JSON các chuỗi string.`
    : `For the ${industry} industry, list 3-5 specific, concise action steps to implement this digital transformation initiative: "${itemTitle}". Return the result as a JSON array of strings.`;

  const response = await ai.models.generateContent({
    model: modelId,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: { type: Type.STRING }
      }
    }
  });

  if (response.text) {
    return JSON.parse(response.text) as string[];
  }
  return [];
};

export const generateRiskAnalysis = async (
  itemTitle: string,
  industry: string,
  language: Language
): Promise<{ risk: string; mitigation: string }[]> => {
  const modelId = "gemini-2.5-flash";
  const prompt = language === 'vi'
    ? `Đối với ngành ${industry}, phân tích 2 rủi ro tiềm ẩn lớn nhất khi thực hiện sáng kiến: "${itemTitle}" và giải pháp phòng ngừa ngắn gọn. Trả về JSON.`
    : `For the ${industry} industry, analyze the top 2 potential risks when implementing: "${itemTitle}" and provide concise mitigation. Return JSON.`;

  const response = await ai.models.generateContent({
    model: modelId,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            risk: { type: Type.STRING },
            mitigation: { type: Type.STRING }
          },
          required: ["risk", "mitigation"]
        }
      }
    }
  });

  if (response.text) {
    return JSON.parse(response.text) as { risk: string; mitigation: string }[];
  }
  return [];
};

export const generateConsultationBrief = async (
  expertName: string,
  expertRole: string,
  assessmentSummary: string,
  language: Language
): Promise<string> => {
  const modelId = "gemini-2.5-flash";
  const prompt = language === 'vi' 
    ? `Dựa trên kết quả đánh giá doanh nghiệp: "${assessmentSummary}", hãy soạn một email mời họp ngắn gọn (dưới 100 từ) gửi đến chuyên gia ${expertName} (${expertRole}). Tập trung vào vấn đề cấp thiết nhất cần tư vấn.`
    : `Based on the business assessment: "${assessmentSummary}", write a concise meeting invitation email (under 100 words) to expert ${expertName} (${expertRole}). Focus on the most urgent issue requiring consultation.`;

  const response = await ai.models.generateContent({
    model: modelId,
    contents: prompt,
  });

  return response.text || "";
};
