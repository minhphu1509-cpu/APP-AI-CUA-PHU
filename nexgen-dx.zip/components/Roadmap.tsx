
import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Clock, 
  Target, 
  ChevronDown, 
  ChevronUp, 
  Bot, 
  Sparkles, 
  BarChart3, 
  Share2, 
  Download,
  CalendarDays,
  ArrowRight,
  LayoutList,
  KanbanSquare,
  AlertTriangle,
  ShieldCheck,
  MoreHorizontal,
  Users
} from 'lucide-react';
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { AssessmentResult, Language, RoadmapItem } from '../types';
import { generateActionPlan, generateRiskAnalysis } from '../services/geminiService';

interface RoadmapProps {
  data: AssessmentResult;
  language: Language;
  onNavigateToAssessment: () => void;
  onFindExpert: (query: string) => void;
}

type RoadmapStatus = 'todo' | 'in_progress' | 'done';
type ViewMode = 'list' | 'board';
type Tab = 'actions' | 'risks';

export const Roadmap: React.FC<RoadmapProps> = ({ data, language, onNavigateToAssessment, onFindExpert }) => {
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [expandedItems, setExpandedItems] = useState<Record<number, boolean>>({});
  const [activeItemTab, setActiveItemTab] = useState<Record<number, Tab>>({});
  
  // Enriched local state
  const [itemStatus, setItemStatus] = useState<Record<number, RoadmapStatus>>({});
  const [actionPlans, setActionPlans] = useState<Record<number, string[]>>({});
  const [riskAnalysis, setRiskAnalysis] = useState<Record<number, { risk: string; mitigation: string }[]>>({});
  
  const [loadingAction, setLoadingAction] = useState<number | null>(null);
  const [loadingRisk, setLoadingRisk] = useState<number | null>(null);

  const t = {
    en: {
      title: "Strategic Roadmap",
      subtitle: `Tailored Transformation Path for ${data.industry || 'Your Enterprise'}`,
      metrics: { velocity: 'Velocity', budget: 'Est. Budget', alignment: 'Alignment' },
      actions: { generate: 'Generate Steps', analyzeRisk: 'Risk Radar', loading: 'Thinking...', export: 'Export PDF', share: 'Share', findExpert: 'Connect Expert' },
      status: { todo: 'To Do', inProgress: 'In Progress', done: 'Completed' },
      kpi: 'Key Result',
      noData: 'No roadmap data available.',
      back: 'Return to Assessment',
      views: { list: 'Timeline', board: 'Board' },
      tabs: { actions: 'Action Plan', risks: 'Risk Analysis' },
      phases: { short: 'Short Term', med: 'Medium Term', long: 'Long Term' }
    },
    vi: {
      title: "Lộ Trình Chiến Lược",
      subtitle: `Hành trình chuyển đổi số cho ngành ${data.industry || 'Doanh nghiệp'}`,
      metrics: { velocity: 'Tốc độ', budget: 'Ngân sách (Ước tính)', alignment: 'Sự phù hợp' },
      actions: { generate: 'Tạo các bước', analyzeRisk: 'Radar Rủi ro', loading: 'Đang xử lý...', export: 'Xuất PDF', share: 'Chia sẻ', findExpert: 'Tìm Chuyên Gia' },
      status: { todo: 'Cần làm', inProgress: 'Đang thực hiện', done: 'Hoàn thành' },
      kpi: 'Chỉ số KPI',
      noData: 'Chưa có dữ liệu lộ trình.',
      back: 'Quay lại Đánh giá',
      views: { list: 'Dòng thời gian', board: 'Bảng Kanban' },
      tabs: { actions: 'Kế hoạch hành động', risks: 'Phân tích rủi ro' },
      phases: { short: 'Ngắn hạn', med: 'Trung hạn', long: 'Dài hạn' }
    }
  }[language];

  const toggleExpand = (index: number) => {
    setExpandedItems(prev => ({ ...prev, [index]: !prev[index] }));
    if (!activeItemTab[index]) setActiveItemTab(prev => ({...prev, [index]: 'actions'}));
  };

  const cycleStatus = (index: number) => {
    setItemStatus(prev => {
      const current = prev[index] || 'todo';
      const next = current === 'todo' ? 'in_progress' : current === 'in_progress' ? 'done' : 'todo';
      return { ...prev, [index]: next };
    });
  };

  const handleGenerateActions = async (item: RoadmapItem, index: number) => {
    if (actionPlans[index]) return; 
    setLoadingAction(index);
    try {
      const steps = await generateActionPlan(item.title, data.industry || 'Business', language);
      setActionPlans(prev => ({ ...prev, [index]: steps }));
    } catch (err) { console.error(err); } 
    finally { setLoadingAction(null); }
  };

  const handleAnalyzeRisks = async (item: RoadmapItem, index: number) => {
    if (riskAnalysis[index]) return;
    setLoadingRisk(index);
    try {
      const risks = await generateRiskAnalysis(item.title, data.industry || 'Business', language);
      setRiskAnalysis(prev => ({ ...prev, [index]: risks }));
    } catch (err) { console.error(err); }
    finally { setLoadingRisk(null); }
  };

  const handleExportPDF = () => {
    const doc = new jsPDF();

    // Branding Colors
    const primaryColor = [229, 56, 59]; // #e5383b
    const darkColor = [22, 26, 29]; // #161a1d

    // Header
    doc.setFont("helvetica", "bold");
    doc.setFontSize(22);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text("NexGen DX", 14, 20);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(12);
    doc.setTextColor(darkColor[0], darkColor[1], darkColor[2]);
    doc.text(t.title, 14, 28);

    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`${t.subtitle} - ${new Date().toLocaleDateString()}`, 14, 34);

    if (data.summary) {
      doc.setFontSize(10);
      doc.setTextColor(60);
      const splitSummary = doc.splitTextToSize(data.summary, 180);
      doc.text(splitSummary, 14, 42);
    }

    // Prepare Table Data
    const tableBody = data.roadmap.map((item, index) => {
      const status = itemStatus[index] || 'todo';
      const statusLabel = status === 'done' ? t.status.done : status === 'in_progress' ? t.status.inProgress : t.status.todo;
      const phaseLabel = item.phase === 'Short Term' ? t.phases.short : item.phase === 'Medium Term' ? t.phases.med : t.phases.long;

      return [
        phaseLabel,
        statusLabel,
        item.title,
        item.kpi
      ];
    });

    const startY = data.summary ? 60 : 45;

    autoTable(doc, {
      startY: startY,
      head: [[language === 'vi' ? 'Giai đoạn' : 'Phase', language === 'vi' ? 'Trạng thái' : 'Status', language === 'vi' ? 'Sáng kiến' : 'Initiative', 'KPI']],
      body: tableBody,
      headStyles: { fillColor: [22, 26, 29], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [245, 243, 244] },
      styles: { fontSize: 9, cellPadding: 4 },
      columnStyles: {
        0: { cellWidth: 30 },
        1: { cellWidth: 25 },
        2: { cellWidth: 'auto' },
        3: { cellWidth: 40 }
      }
    });

    // Add Footer
    const pageCount = (doc as any).internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(8);
      doc.setTextColor(150);
      doc.text(`Generated by NexGen DX AI Platform - Page ${i} of ${pageCount}`, 14, doc.internal.pageSize.height - 10);
    }

    doc.save("NexGenDX_Roadmap.pdf");
  };

  // Helper to get consistent colors per phase
  const getPhaseColor = (phase: string) => {
    if (phase.includes('Short')) return { bg: 'bg-emerald-500/10', border: 'border-emerald-500/30', text: 'text-emerald-400', dot: 'bg-emerald-500' };
    if (phase.includes('Medium')) return { bg: 'bg-amber-500/10', border: 'border-amber-500/30', text: 'text-amber-400', dot: 'bg-amber-500' };
    return { bg: 'bg-brand-bright/10', border: 'border-brand-bright/30', text: 'text-brand-bright', dot: 'bg-brand-bright' };
  };

  const getStatusBadge = (status: RoadmapStatus) => {
    switch (status) {
      case 'done': return <span className="flex items-center gap-1 text-[10px] font-bold uppercase text-brand-black bg-green-500 px-2 py-0.5 rounded">{t.status.done}</span>;
      case 'in_progress': return <span className="flex items-center gap-1 text-[10px] font-bold uppercase text-white bg-blue-500 px-2 py-0.5 rounded animate-pulse">{t.status.inProgress}</span>;
      default: return <span className="flex items-center gap-1 text-[10px] font-bold uppercase text-brand-gray bg-white/10 px-2 py-0.5 rounded border border-white/5">{t.status.todo}</span>;
    }
  };

  const roadmapItemsWithIndex = data.roadmap.map((item, idx) => ({ ...item, idx }));

  // Render Content Logic
  const renderItemCard = (item: RoadmapItem & { idx: number }, compact: boolean = false) => {
    const idx = item.idx;
    const status = itemStatus[idx] || 'todo';
    const isExpanded = expandedItems[idx];
    const colors = getPhaseColor(item.phase);
    const hasActions = !!actionPlans[idx];
    const hasRisks = !!riskAnalysis[idx];
    const currentTab = activeItemTab[idx] || 'actions';

    return (
      <div 
        key={idx} 
        className={`group relative rounded-xl border transition-all duration-300 ${
          isExpanded 
            ? 'bg-brand-dark border-brand-bright/30 shadow-2xl z-10' 
            : 'bg-brand-dark/40 border-white/5 hover:border-white/20 hover:bg-brand-dark/60'
        } ${compact ? 'p-4' : 'p-0'}`}
      >
        <div className={compact ? '' : 'p-5 cursor-pointer'} onClick={() => !compact && toggleExpand(idx)}>
          {/* Header Row */}
          <div className="flex items-start justify-between gap-3 mb-2">
             <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${colors.dot}`}></span>
                <span className={`text-[10px] font-mono uppercase tracking-wider ${colors.text}`}>
                  {item.phase}
                </span>
             </div>
             <button onClick={(e) => { e.stopPropagation(); cycleStatus(idx); }}>
               {getStatusBadge(status)}
             </button>
          </div>

          {/* Title & Desc */}
          <h3 className={`font-bold text-white mb-2 leading-tight ${compact ? 'text-sm' : 'text-lg'}`}>
            {item.title}
          </h3>
          <p className={`text-brand-gray text-xs leading-relaxed ${!isExpanded && !compact ? 'line-clamp-2' : ''}`}>
            {item.description}
          </p>

          {/* Footer Metrics - KPI Highlight */}
          <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between">
             <div className="bg-brand-black/40 px-3 py-1.5 rounded-lg border border-white/10 flex items-center gap-2 group-hover:border-brand-bright/30 transition-colors">
               <Target size={14} className="text-brand-bright" />
               <span className="text-[10px] text-brand-gray font-mono uppercase tracking-wider font-bold">KPI:</span>
               <span className="text-xs font-bold text-white tracking-tight">{item.kpi}</span>
             </div>
             
             {!compact && (
               <div className="text-brand-gray group-hover:text-white transition-colors">
                 {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
               </div>
             )}
          </div>
        </div>

        {/* Deep Dive Panel (Only in List View or Expanded) */}
        {isExpanded && !compact && (
          <div className="px-5 pb-5 animate-in fade-in slide-in-from-top-2">
            
            {/* Tabs & Actions */}
            <div className="flex items-center justify-between mb-4 bg-brand-black/40 p-1 rounded-lg">
              <div className="flex items-center gap-1">
                <button 
                  onClick={(e) => { e.stopPropagation(); setActiveItemTab(prev => ({...prev, [idx]: 'actions'})); }}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-2 ${currentTab === 'actions' ? 'bg-brand-bright text-white shadow' : 'text-brand-gray hover:text-white'}`}
                >
                  <Bot size={12} /> {t.tabs.actions}
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); setActiveItemTab(prev => ({...prev, [idx]: 'risks'})); }}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-2 ${currentTab === 'risks' ? 'bg-brand-red text-white shadow' : 'text-brand-gray hover:text-white'}`}
                >
                  <AlertTriangle size={12} /> {t.tabs.risks}
                </button>
              </div>
              
              <button 
                onClick={(e) => { e.stopPropagation(); onFindExpert(item.title); }}
                className="px-3 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-2 text-brand-bright hover:text-white hover:bg-brand-bright/20 border border-transparent hover:border-brand-bright/30"
              >
                <Users size={12} /> {t.actions.findExpert}
              </button>
            </div>

            {/* Actions Tab Content */}
            {currentTab === 'actions' && (
              <div className="bg-brand-black/30 rounded-xl p-4 border border-white/5 min-h-[120px]">
                {!hasActions ? (
                  <div className="flex flex-col items-center justify-center h-full py-4">
                     <button 
                      onClick={(e) => { e.stopPropagation(); handleGenerateActions(item, idx); }}
                      disabled={loadingAction === idx}
                      className="flex items-center gap-2 bg-white/5 hover:bg-white/10 text-brand-bright border border-brand-bright/30 px-4 py-2 rounded-lg text-xs font-bold transition-all"
                    >
                      {loadingAction === idx ? <Sparkles size={14} className="animate-spin" /> : <Bot size={14} />}
                      {loadingAction === idx ? t.actions.loading : t.actions.generate}
                    </button>
                  </div>
                ) : (
                  <ul className="space-y-2">
                    {actionPlans[idx].map((step, sIdx) => (
                       <li key={sIdx} className="flex gap-3 text-sm text-brand-light items-start">
                          <CheckCircle2 size={14} className="mt-1 text-green-500 shrink-0" />
                          <span className="leading-relaxed text-xs">{step}</span>
                       </li>
                    ))}
                  </ul>
                )}
              </div>
            )}

            {/* Risks Tab Content */}
            {currentTab === 'risks' && (
               <div className="bg-brand-black/30 rounded-xl p-4 border border-white/5 min-h-[120px]">
                 {!hasRisks ? (
                   <div className="flex flex-col items-center justify-center h-full py-4">
                      <p className="text-[10px] text-brand-gray mb-3 text-center opacity-70">
                        {language === 'vi' ? 'Phân tích rủi ro & giải pháp' : 'Identify risks & mitigations'}
                      </p>
                      <button 
                       onClick={(e) => { e.stopPropagation(); handleAnalyzeRisks(item, idx); }}
                       disabled={loadingRisk === idx}
                       className="flex items-center gap-2 bg-white/5 hover:bg-white/10 text-orange-400 border border-orange-400/30 px-4 py-2 rounded-lg text-xs font-bold transition-all"
                     >
                       {loadingRisk === idx ? <Sparkles size={14} className="animate-spin" /> : <AlertTriangle size={14} />}
                       {loadingRisk === idx ? t.actions.loading : t.actions.analyzeRisk}
                     </button>
                   </div>
                 ) : (
                   <div className="grid grid-cols-1 gap-3 animate-in fade-in zoom-in-95">
                     {riskAnalysis[idx].slice(0, 2).map((r, rIdx) => (
                        <div key={rIdx} className="bg-brand-dark/50 border border-white/5 p-3 rounded-lg hover:border-orange-500/30 transition-colors">
                           <div className="flex items-start gap-2 text-orange-400 font-bold text-xs mb-1">
                              <AlertTriangle size={14} className="shrink-0 mt-0.5" />
                              <span className="leading-tight">{r.risk}</span>
                           </div>
                           <div className="flex items-start gap-2 text-brand-gray text-[11px] leading-relaxed pl-6">
                              <ShieldCheck size={12} className="text-green-500 shrink-0 mt-0.5" />
                              <span className="opacity-90">{r.mitigation}</span>
                           </div>
                        </div>
                     ))}
                   </div>
                 )}
               </div>
            )}
            
          </div>
        )}
      </div>
    );
  };

  const completedCount = Object.values(itemStatus).filter(s => s === 'done').length;
  const progress = Math.round((completedCount / data.roadmap.length) * 100);

  if (!data || !data.roadmap.length) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-8">
        <h2 className="text-2xl text-white font-display font-bold mb-4">{t.noData}</h2>
        <button onClick={onNavigateToAssessment} className="bg-brand-bright text-white px-6 py-3 rounded-full hover:bg-brand-red transition-colors flex items-center">
          {t.back} <ArrowRight size={18} className="ml-2"/>
        </button>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-brand-black overflow-hidden relative">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-brand-wine/10 via-transparent to-transparent pointer-events-none" />
      
      {/* 1. Header & Stats */}
      <div className="p-6 md:p-8 border-b border-white/5 bg-brand-dark/50 backdrop-blur-md z-20">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
               <span className="bg-brand-bright text-white text-[10px] font-bold px-2 py-0.5 rounded uppercase">AI Generated</span>
               <h1 className="text-3xl font-display font-bold text-white">{t.title}</h1>
            </div>
            <p className="text-brand-gray text-sm flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span>
              {t.subtitle}
            </p>
          </div>
          <div className="flex items-center gap-3">
             <div className="bg-brand-black/40 rounded-lg p-1 border border-white/10 flex">
                <button 
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded flex items-center gap-2 text-xs font-medium transition-all ${viewMode === 'list' ? 'bg-white/10 text-white' : 'text-brand-gray hover:text-white'}`}
                >
                  <LayoutList size={16} /> {t.views.list}
                </button>
                <div className="w-px bg-white/5 mx-1"></div>
                <button 
                  onClick={() => setViewMode('board')}
                  className={`p-2 rounded flex items-center gap-2 text-xs font-medium transition-all ${viewMode === 'board' ? 'bg-white/10 text-white' : 'text-brand-gray hover:text-white'}`}
                >
                  <KanbanSquare size={16} /> {t.views.board}
                </button>
             </div>
             <button 
              onClick={handleExportPDF}
              className="flex items-center gap-2 px-4 py-2 bg-brand-bright text-white rounded-lg hover:bg-brand-red transition-colors shadow-lg shadow-brand-red/20 text-xs font-bold"
             >
                <Download size={18} />
                <span>{t.actions.export}</span>
             </button>
          </div>
        </div>

        {/* Executive Metrics Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
           {/* Metric 1 */}
           <div className="bg-brand-dark border border-white/5 p-3 rounded-lg flex items-center gap-3">
              <div className="p-2 bg-blue-500/10 rounded-lg text-blue-400"><Clock size={18}/></div>
              <div>
                 <p className="text-[10px] text-brand-gray uppercase font-bold">{t.metrics.velocity}</p>
                 <p className="text-white font-mono text-sm">24 wks</p>
              </div>
           </div>
           {/* Metric 2 */}
           <div className="bg-brand-dark border border-white/5 p-3 rounded-lg flex items-center gap-3">
              <div className="p-2 bg-green-500/10 rounded-lg text-green-400"><BarChart3 size={18}/></div>
              <div>
                 <p className="text-[10px] text-brand-gray uppercase font-bold">{t.metrics.budget}</p>
                 <p className="text-white font-mono text-sm">$150k</p>
              </div>
           </div>
           {/* Metric 3 */}
           <div className="bg-brand-dark border border-white/5 p-3 rounded-lg flex items-center gap-3">
              <div className="p-2 bg-amber-500/10 rounded-lg text-amber-400"><Target size={18}/></div>
              <div>
                 <p className="text-[10px] text-brand-gray uppercase font-bold">{t.metrics.alignment}</p>
                 <p className="text-white font-mono text-sm">98%</p>
              </div>
           </div>
           {/* Metric 4: Progress */}
           <div className="bg-brand-dark border border-white/5 p-3 rounded-lg relative overflow-hidden">
              <div className="absolute top-0 left-0 bottom-0 bg-brand-bright/10 transition-all duration-700" style={{ width: `${progress}%` }}></div>
              <div className="relative z-10 flex justify-between items-center h-full">
                 <span className="text-[10px] text-brand-gray uppercase font-bold">Total Completion</span>
                 <span className="text-brand-bright font-bold font-mono">{progress}%</span>
              </div>
           </div>
        </div>
      </div>

      {/* 2. Main Content Area */}
      <div className="flex-1 overflow-y-auto overflow-x-hidden p-6 md:p-8 bg-brand-black/80">
        
        {/* LIST VIEW */}
        {viewMode === 'list' && (
          <div className="max-w-4xl mx-auto space-y-8">
            {['Short Term', 'Medium Term', 'Long Term'].map((phase) => {
               const items = roadmapItemsWithIndex.filter(i => i.phase === phase);
               if (items.length === 0) return null;
               
               const phaseColors = getPhaseColor(phase);
               
               return (
                 <div key={phase} className="relative pl-8 border-l border-white/10">
                    <span className={`absolute -left-3 top-0 w-6 h-6 rounded-full border-4 border-brand-black ${phaseColors.dot} flex items-center justify-center shadow-[0_0_15px_rgba(0,0,0,0.5)]`}></span>
                    
                    <div className="mb-6">
                       <h2 className={`text-xl font-display font-bold ${phaseColors.text}`}>
                         {phase === 'Short Term' ? t.phases.short : phase === 'Medium Term' ? t.phases.med : t.phases.long}
                       </h2>
                       <p className="text-brand-gray text-xs uppercase tracking-widest mt-1">Strategic Phase</p>
                    </div>

                    <div className="space-y-4">
                       {items.map(item => renderItemCard(item))}
                    </div>
                 </div>
               )
            })}
          </div>
        )}

        {/* BOARD VIEW (KANBAN) */}
        {viewMode === 'board' && (
          <div className="h-full overflow-x-auto">
             <div className="flex gap-6 min-w-[1000px] h-full">
                {(['todo', 'in_progress', 'done'] as const).map(colStatus => {
                   const colItems = roadmapItemsWithIndex.filter(i => (itemStatus[i.idx] || 'todo') === colStatus);
                   const colTitle = colStatus === 'todo' ? t.status.todo : colStatus === 'in_progress' ? t.status.inProgress : t.status.done;
                   const colColor = colStatus === 'in_progress' ? 'border-blue-500/50' : colStatus === 'done' ? 'border-green-500/50' : 'border-white/10';

                   return (
                      <div key={colStatus} className="flex-1 flex flex-col h-full bg-brand-dark/20 rounded-2xl border border-white/5">
                         {/* Column Header */}
                         <div className={`p-4 border-b ${colColor} bg-brand-black/20 rounded-t-2xl flex justify-between items-center`}>
                            <span className="font-bold text-sm text-white uppercase tracking-wider">{colTitle}</span>
                            <span className="bg-white/10 text-xs px-2 py-0.5 rounded-full text-brand-gray font-mono">{colItems.length}</span>
                         </div>
                         
                         {/* Droppable Area (Visual only) */}
                         <div className="flex-1 p-3 space-y-3 overflow-y-auto">
                            {colItems.map(item => renderItemCard(item, true))}
                            {colItems.length === 0 && (
                               <div className="h-32 border-2 border-dashed border-white/5 rounded-xl flex items-center justify-center text-brand-gray/30 text-xs uppercase">
                                  Empty
                               </div>
                            )}
                         </div>
                      </div>
                   )
                })}
             </div>
          </div>
        )}
      </div>
    </div>
  );
};
